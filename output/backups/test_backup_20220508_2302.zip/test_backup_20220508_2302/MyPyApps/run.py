import sys
import os
from datetime import datetime
from src.app import main

def run():
    print("Current Time:", datetime.today().strftime("%m/%d"), datetime.now().strftime("%H:%M:%S"))
    main()

# Open self in close-on-success terminal if --dbg (and no --cmd)
run() if (not "--dbg" in sys.argv) or ("--cmd" in sys.argv) else os.system("start cmd /k python " + sys.argv[0] + " --dbg --cmd ^&^& exit")