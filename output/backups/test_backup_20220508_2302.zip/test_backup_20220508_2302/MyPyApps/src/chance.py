import random

def roll_die(sides):
    return random.randint(1, sides)