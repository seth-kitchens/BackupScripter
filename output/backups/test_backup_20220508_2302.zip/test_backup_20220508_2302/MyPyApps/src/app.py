import os
import sys

import PySimpleGUI as sg

class PyApp:
    apps = {} # app_id -> py_app
    apps_by_button_key = {}
    def __init__(self, app_name, app_id, working_dir, app_args) -> None:
        self.app_name = app_name
        self.app_id = app_id
        self.working_dir = working_dir
        self.app_args = app_args
    def define(py_app):
        PyApp.apps[py_app.app_id] = py_app
        PyApp.apps_by_button_key[py_app.get_button_key()] = py_app
    def handle_event(window, event, values):
        if event in PyApp.apps_by_button_key.keys():
            py_app = PyApp.apps_by_button_key[event]
            return py_app
    def run(self):
        os.chdir(self.working_dir)
        if "--dbg" in sys.argv:
            call_parts = ["start cmd /k python", *self.app_args, "--dbg --cmd ^&^& exit"]
        else:
            call_parts = ["start pythonw", *self.app_args]
        os.system(" ".join(call_parts))
    def get_button_key(self):
        return "Button" + self.app_id
    def get_button(self):
        return sg.Button(self.app_name, key=self.get_button_key())

PyApp.define(PyApp(
    app_name="Real Wage Calculator",
    app_id="RWC",
    working_dir="apps/RealWageCalc",
    app_args=["run.py"]
))
PyApp.define(PyApp(
    app_name="Backup Scripter",
    app_id="BS",
    working_dir="apps/BackupScripter",
    app_args=["editor.py"]
))

def event_loop():
    apps = PyApp.apps
    layout = [
        [sg.Text("Apps", text_color="gold")],
        [apps["RWC"].get_button()],
        [apps["BS"].get_button()],
        #[apps["AS"].get_button()],
        [sg.HSeparator()],
        [sg.Button("QUIT")]
    ]

    window = sg.Window("MyPyApps", layout)

    app_chosen = None

    while True:
        event, values = window.read()

        app_chosen = PyApp.handle_event(window, event, values)
        if app_chosen:
            break
        elif event == "QUIT" or event == sg.WIN_CLOSED:
            break
    
    window.close()

    if app_chosen:
        app_chosen.run()
    
#end event_loop()

def main():
    event_loop()
    #audio_shop.play_sound_file_simple('audio/classical.wav')

#main() end