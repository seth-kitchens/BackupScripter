eryx_location = 'C:\\Main\\Python\\Lib\\eryxlib\\ver_0_1'
"""path to eryxlib/ver_X_X folder, which contains an eryx folder"""

eryx_path = eryx_location + '\\' + 'eryx'
"""path to eryxlib/ver_X_X/eryx"""