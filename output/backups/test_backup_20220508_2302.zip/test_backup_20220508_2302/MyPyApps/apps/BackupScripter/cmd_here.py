import os
os.system("start cmd .")