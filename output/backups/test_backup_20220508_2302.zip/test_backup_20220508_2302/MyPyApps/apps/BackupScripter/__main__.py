import sys
from depends import eryx_location
sys.path.append(eryx_location)
from src.project import g
from eryx.project import utils as project_utils

flags = g.constants.flags

# TODO Convert above-function comments to docstrings (informal is fine)
# TODO Look for functions that need pop-up info, then add docstrings accordingly
# TODO Look over and update existing documentation

if __name__ != '__main__':
    sys.exit()

argv_flags = project_utils.extract_argv_flags()


def run():
    action_flags = [flags.GETDATA, flags.EDITOR, flags.BACKUP]
    actions = [f for f in action_flags if f in argv_flags]
    if len(actions) > 1:
        print("Only one action may be specified.")
        sys.exit()
    if len(actions) < 1:
        argv_flags.append(flags.EDITOR)

    if flags.EDITOR in argv_flags:
        exe = "run_editor.py"
    elif flags.BACKUP in argv_flags or flags.GETDATA in argv_flags:
        exe = "run_backup.py"

    project_utils.open_in_terminal(exe, argv_flags)


if flags.DBGCMD in argv_flags and not flags.DBGCMD in argv_flags:
    argv_flags.append(flags.DBGCMD)
    project_utils.open_in_terminal(sys.argv[0], argv_flags)
else:
    run()