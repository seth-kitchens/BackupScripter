import sys

from depends import eryx_location
sys.path.append(eryx_location)

from eryx.project import utils as project_utils

from src.backup.app import app
from src.project import g
from src.project.script_data import ScriptDataManagerBS as sdm_bs

flags = g.constants.flags
argv_flags = project_utils.extract_argv_flags()

if __name__ == "__main__":
    if flags.DEBUG in argv_flags:
        project_utils.print_current_time()
    script_manager = sdm_bs()
    if flags.GETDATA in argv_flags:
        script_manager.get_data()
    else:
        app(script_manager)
