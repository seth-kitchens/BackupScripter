from eryx.gui.elements import VFSExplorerView
from eryx.gui.ge.ge import *

__all__ = ['VFSExplorerViewBS']

class VFSExplorerViewBS(VFSExplorerView):
    def __init__(self, object_id, vfs_explorer) -> None:
        super().__init__(object_id, vfs_explorer)

    ### GuiElement
    ### VFSExplorerView

    def define_events(self):
        super().define_events()
        def event_add_folder(window, event, values, data):
            item_path = values[self.keys['AddFolder']]
            if item_path == '':
                return
            self.vfs.add_path(item_path)
            self.vfs.calc_root(item_path)
            self.vfs_explorer.exit_to_root()
            self.push(window)
        self.em.event_function(self.keys['AddFolder'], event_add_folder)
        
        def event_add_files(window, event, values, data):
            item_paths = values[self.keys['AddFiles']].split(';')
            if len(item_paths) <= 0:
                return
            for item_path in item_paths:
                self.vfs.add_path(item_path)
            self.vfs.calc_all()
            self.vfs_explorer.exit_to_root()
            self.push(window)
        self.em.event_function(self.keys['AddFiles'], event_add_files)

        def event_remove(window, event, values, data):
            if not self.selection:
                return
            path = self.selection.get_path()
            root = self.vfs.find_root_entry(path)
            if path != root.get_path():
                self.handle_event(window, self.keys['Exclude'], values, data)
            else:
                self.vfs.remove(path)
            root.calc_ie()
            self.vfs_explorer.refresh_current_dir()
            self.deselect()
            self.push(window)
        self.em.event_function(self.keys['Remove'], event_remove)

        ### VFSExplorerViewBS

        def event_include(window, event, values, data):
            if not self.selection:
                return
            self.selection.include()
            root = self.vfs.find_root_entry(self.selection.get_path())
            root.calc_ie()
            self.push(window)
        self.em.event_function(self.keys['Include'], event_include)

        def event_exclude(window, event, values, data):
            if not self.selection:
                return
            self.selection.exclude()
            path = self.selection.get_path()
            root = self.vfs.find_root_entry(path)
            if path == root.get_path():
                self.handle_event(window, self.keys['Remove'], values, data)
                return
            root.calc_ie()
            self.push(window)
        self.em.event_function(self.keys['Exclude'], event_exclude)
