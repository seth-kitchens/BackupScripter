import json

from src.editor.gui.elements import DetailListBS
from src.editor.info import matching_groups_list as info
from eryx.data import units as unit
from eryx.gui.elements import *
from eryx.gui.ge import utils as ge_utils
from eryx.gui.ge.gem import *
from eryx.gui.sg.utils import EmbedText, button_size
from src.editor.gui.windows.edit_matching_group import WindowEditMatchingGroups

__all__ = ['MatchingGroupsList']

class MatchingGroupsList(DetailListBS):
    def __init__(self, object_id, vfs):
        super().__init__(object_id)

    ### DetailList

    def make_details(self, item, data):
        if data == None:
            return EmbedText('No Data')
        
        # Action

        ie_action = data['IE']

        # Apply To
        
        apply_to_files = data['ApplyToFiles']
        apply_to_folders = data['ApplyToFolders']
        apply_recursive = data['ApplyRecursive']
        min_file_size = data['MinFileSize']
        max_file_size = data['MaxFileSize']
        min_folder_size = data['MinFolderSize']
        max_folder_size = data['MaxFolderSize']

        # Apply If
        
        within_path = data['WithinPath']
        not_within_paths = data['NotWithinPaths']
        apply_if_extensions = data['ApplyIfExtensions']
        do_not_apply_if_extensions = data['DoNotApplyIfExtensions']
        min_parent_folder_size = data['MinParentFolderSize']
        max_parent_folder_size = data['MaxParentFolderSize']

        # Apply Group If

        max_backup_size_before = data['MaxBackupSizeBefore']
        max_backup_size_after = data['MaxBackupSizeAfter']
        min_backup_size_before = data['MinBackupSizeBefore']
        min_backup_size_after = data['MinBackupSizeAfter']
        max_total_size_diff = data['MaxTotalSizeDiff']
        min_total_size_diff = data['MinTotalSizeDiff']

        # Patterns

        strip_extensions = data['StripExtensions']
        match_case = data['MatchCase']
        use_regex = data['UseRegex']
        whole_name = data['WholeName']
        match_all = data['MatchAll']
        patterns = data['Patterns']

        def negative_to_none(x):
            if x == None or x >= 0:
                return x
            return None

        min_file_size = negative_to_none(min_file_size)
        max_file_size = negative_to_none(max_file_size)
        min_folder_size = negative_to_none(min_folder_size)
        max_folder_size = negative_to_none(max_folder_size)
        min_parent_folder_size = negative_to_none(min_parent_folder_size)
        max_parent_folder_size = negative_to_none(max_parent_folder_size)

        max_backup_size_before = negative_to_none(max_backup_size_before)
        max_backup_size_after = negative_to_none(max_backup_size_after)
        min_backup_size_before = negative_to_none(min_backup_size_before)
        min_backup_size_after = negative_to_none(min_backup_size_after)
        max_total_size_diff = negative_to_none(max_total_size_diff)
        min_total_size_diff = negative_to_none(min_total_size_diff)

        highlights = {
            'green': '#aaffaa',
            'blue': '#bbbbff',
            'purple': '#dfbbff'
        }
        colors_var = ('black', highlights['green'])
        colors_bad = ('black', 'orange')
        colors_alert = ('black', 'yellow')
        colors_pattern = ('black', highlights['blue'])
        colors_cond = ('black', highlights['purple'])
        et = EmbedText()
        def et_text(s):
            et.append(s)
        def et_var(s):
            et.color(s, *colors_var)
        def et_bad(s):
            et.color(s, *colors_bad)
        def et_pattern(s):
            et.color(s, *colors_pattern)
        def et_cond(s):
            et.color(s, *colors_cond)
        def et_alert(s):
            et.color(s, *colors_alert)
        
        cond_f_sz = cond_F_sz = cond_pF_sz = cond_apply_if = False
        if apply_to_files and (min_file_size or max_file_size):
            cond_f_sz = True
        if apply_to_folders and (min_folder_size or max_folder_size):
            cond_F_sz = True
        if min_parent_folder_size or max_parent_folder_size:
            cond_pF_sz = True
        if cond_f_sz or cond_F_sz or cond_pF_sz:
            cond_apply_if = True
        
        cond_bsb = cond_bsa = cond_tsd = cond_apply_group_if = False
        if min_backup_size_before or max_backup_size_before:
            cond_bsb = True
        if min_backup_size_after or max_backup_size_after:
            cond_bsa = True
        if min_total_size_diff or max_total_size_diff:
            cond_tsd = True
        if cond_bsb or cond_bsa or cond_tsd:
            cond_apply_group_if = True
        
        has_cond = False
        if patterns or cond_apply_if or cond_apply_group_if:
            has_cond = True
        elif within_path or not_within_paths:
            has_cond = True
        elif apply_if_extensions or do_not_apply_if_extensions:
            has_cond = True
        

        s_ie_action = '[' + ie_action.capitalize() + ']'
        et_var(s_ie_action)
        et_text(' ')

        if apply_to_files and apply_to_folders:
            if not has_cond:
                et_bad('[All]')
                return et
            s_types = 'Files/Folders'
        elif apply_to_files:
            if not has_cond:
                et_bad('[All Files]')
                return et
            s_types = 'Files'
        elif apply_to_folders:
            if not has_cond:
                et_bad('[All Folders]')
                return et
            s_types = 'Folders'
        else:
            et_bad('[None]')
            return et

        s = '['
        if apply_to_files:
            s += 'Files'
            if apply_to_folders:
                s += ', '
        et_var(s)
        s = ''
        if apply_to_folders:
            s += 'Folders'
            if not apply_recursive:
                s += ' (NR)'
        if apply_if_extensions or do_not_apply_if_extensions:
            et_bad(s)
            et_var(']')
        else:
            et_var(s + ']')
        
        if within_path:
            et_text(' from ')
            et_var('["' + within_path + '"]')
        else:
            et_text(' from ')
            et_var('[Included]')
        if not_within_paths:
            et_text(' and not within paths: ')
            et_var('[' + ', '.join(['"' + p + '"' for p in not_within_paths]) + ']')

        et_text(' ')
        if apply_if_extensions:
            s1 = 'if any of extensions '
            s2 = '[' + ', '.join(apply_if_extensions) + ']'
            if do_not_apply_if_extensions or apply_to_folders:
                et_bad(s1 + s2)
            else:
                et_text(s1)
                et_var(s2)
        if do_not_apply_if_extensions:
            s1 = 'not any of extensions '
            s2 = '[' + ', '.join(do_not_apply_if_extensions) + ']'
            if apply_if_extensions:
                et_bad(' but ' + s1 + s2)
            elif apply_to_folders:
                et_bad('if ' + s1 + s2)
            else:
                et_text('if ' + s1)
                et_var(s2)

        if patterns:
            et_text('\nMatches names with ')
            if match_all:
                et_var('[All]')
            else:
                et_var('[Any]')
            et_text(' of ')
            if use_regex:
                et_var('[Regex]')
            else:
                et_var('[Text]')
            et_text(' patterns below, with conditions ')
            s = '[Match Case' if match_case else '[Match Case'
            s += ', Whole ' if whole_name else ', In '
            s += 'Name (Stripped)]' if strip_extensions else 'Name]'
            et_var(s)
            s_indent = '\n  '
            for pattern in ['"' + p + '"' for p in patterns]:
                et_text(s_indent)
                et_pattern(pattern)

        def below_size(a):
            et_cond('[Below ' + unit.Bytes(a, unit.Bytes.B).get_best() + ']')
        def above_size(a):
            et_cond('[Above ' + unit.Bytes(a, unit.Bytes.B).get_best() + ']')
        def within_size(a, b):
            if not (a or b):
                return
            if not a:
                return below_size(b)
            if not b:
                return above_size(a)
            s = '[Between '
            s += unit.Bytes(a, unit.Bytes.B).get_best(decimal_digits=1, minimum=0.5)
            s += ' and '
            s += unit.Bytes(b, unit.Bytes.B).get_best(decimal_digits=1, minimum=0.5)
            s += ']'
            if a < b:
                et_cond(s)
            else:
                et_bad(s)
        
        if cond_apply_if:
            et_text('\nApply to:')
        if cond_f_sz or (cond_F_sz and apply_to_files):
            if cond_f_sz:
                et_text('\n  Files ')
                within_size(min_file_size, max_file_size)
            else:
                et_text('\n  Files of any size.')
        if cond_F_sz or (cond_f_sz and apply_to_folders):
            if cond_F_sz:
                et_text('\n  Folders ')
                within_size(min_folder_size, max_folder_size)
            else:
                et_text('\n  Folders of any size')
        if cond_pF_sz:
            et_text('\n  ' + s_types + ' within folders ')
            within_size(min_parent_folder_size, max_parent_folder_size)
        
        if cond_apply_group_if:
            et_text('\nApply Group If:')
        if cond_bsb:
            et_text('\n  Included size before ')
            within_size(min_backup_size_before, max_backup_size_before)
        if cond_bsa:
            et_text('\n  Included size after ')
            within_size(min_backup_size_after, max_backup_size_after)
        if cond_tsd:
            et_text('\n  Included size change ')
            within_size(min_total_size_diff, max_total_size_diff)

        return et
    
    def edit_data(self, item, data):
        if data == None:
            data = self.init_data()

        window_edit_matching_groups = WindowEditMatchingGroups('Matching Group "' + item + '"', data)
        if window_edit_matching_groups.open():
            data.update(window_edit_matching_groups.get_data())
        return data

    def data_to_string(self, data):
        if data == None:
            data = self.init_data()
        return json.dumps(data)
    
    def data_from_string(self, s):
        if not s:
            return self.init_data()
        return json.loads(s)
    
    ### MatchingGroupsList

    def init_data(self):
        data = {}
        data['IE'] = 'exclude' # 'include' | 'exclude'

        # Pattern Options

        data['StripExtensions'] = False
        data['MatchCase'] = False
        data['UseRegex'] = False
        data['WholeName'] = False
        data['MatchAll'] = False

        # Apply To

        data['ApplyToFiles'] = False
        data['ApplyToFolders'] = False
        data['ApplyRecursive'] = False
        data['MinFileSize'] = -1
        data['MaxFileSize'] = -1
        data['MinFolderSize'] = -1
        data['MaxFolderSize'] = -1

        # Apply If
        
        data['WithinPath'] = ''
        data['NotWithinPaths'] = []
        data['ApplyIfExtensions'] = []
        data['DoNotApplyIfExtensions'] = []

        data['MinTotalSizeDiff'] = -1
        data['MaxTotalSizeDiff'] = -1
        data['MinParentFolderSize'] = -1
        data['MaxParentFolderSize'] = -1

        data['MaxBackupSizeBefore'] = -1
        data['MaxBackupSizeAfter'] = -1
        data['MinBackupSizeBefore'] = -1
        data['MinBackupSizeAfter'] = -1

        data['Patterns'] = []
        return data

