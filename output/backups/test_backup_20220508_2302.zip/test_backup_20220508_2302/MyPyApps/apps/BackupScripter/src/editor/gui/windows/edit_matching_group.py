import json

from src.editor.gui.elements import DetailListBS
from src.editor.info import matching_groups_list as info
from eryx.data import units as unit
from eryx.gui.elements import *
from eryx.gui.ge import utils as ge_utils
from eryx.gui.ge.gem import *
from eryx.gui.sg.utils import EmbedText, button_size
from eryx.gui.window import Window

class WindowEditMatchingGroups(Window):
    def __init__(self, title, data=None) -> None:
        super().__init__(title, data)
    
    # Layout

    def get_layout(self):
        gem = self.gem
        column_file_size = sg.Column(expand_x=True, element_justification='center', layout=[
            [sg.Text('Files Within Size')],
            [sg.Sizer(0, 3)],
            gem.row(InputUnits('MaxFileSize', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            gem.row(InputUnits('MinFileSize', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ])
        column_folder_size = sg.Column(expand_x=True, element_justification='center', layout=[
            [sg.Text('Folders Within Size')],
            [sg.Sizer(0, 3)],
            gem.row(InputUnits('MaxFolderSize', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            gem.row(InputUnits('MinFolderSize', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ])
        column_total_size = sg.Column(expand_x=True, element_justification='center', layout=[
            [sg.Text('Total Size Diff')],
            [sg.Sizer(0, 3)],
            gem.row(InputUnits('MaxTotalSizeDiff', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            gem.row(InputUnits('MinTotalSizeDiff', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ])
        column_backup_size_before = sg.Column(expand_x=True, element_justification='center', layout=[
            [sg.Text('Backup Size Before')],
            [sg.Sizer(0, 3)],
            gem.row(InputUnits('MaxBackupSizeBefore', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            gem.row(InputUnits('MinBackupSizeBefore', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ])
        column_backup_size_after = sg.Column(expand_x=True, element_justification='center', layout=[
            [sg.Text('Backup Size After')],
            [sg.Sizer(0, 3)],
            gem.row(InputUnits('MaxBackupSizeAfter', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            gem.row(InputUnits('MinBackupSizeAfter', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ])
        row_parent_folder_size = [
            sg.Text('Parent Folder Size:'),
            *gem.row(InputUnits('MaxParentFolderSize', 'Max', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True)),
            sg.Sizer(5, 0),
            *gem.row(InputUnits('MinParentFolderSize', 'Min', unit.Bytes, default_degree=unit.Bytes.MB, store_as_degree=unit.Bytes.B, negative_invalid=True))
        ]
        row_apply_to_size = [
            column_file_size,
            column_folder_size,
        ]
        row_apply_group_if_size = [
            sg.Push(),
            column_backup_size_before,
            sg.Push(),
            column_backup_size_after,
            sg.Push(),
            column_total_size,
            sg.Push(),
        ]
        frame_apply_to = sg.Frame('Apply To', layout=[
            [
                gem.sge(Checkbox('ApplyToFiles', 'Files')),
                gem.sge(Checkbox('ApplyToFolders', 'Folders').sg_kwargs_checkbox(enable_events=True)),
                gem.sge(Checkbox('ApplyRecursive', 'Recursive'))
            ],
            row_apply_to_size
        ])
        frame_apply_if = sg.Frame('Apply If', expand_x=True, layout=[
            [*gem.row(Path('WithinPath', 'Within path:', blank_invalid=True)), ge_utils.info(gem, 'If empty, applies to all included/excluded before this group.')],
            [
                *gem.row(StringContainer('Not within paths:',
                    TextList('NotWithinPaths', delim=';', strip=' ', lstrip='.'), folder_browse=True, blank_invalid=True
                ))
            ],
            [
                *gem.row(StringContainer('Has extensions:',
                    TextList('ApplyIfExtensions', delim=',', strip=' ', lstrip='.'), blank_invalid=True
                ))
            ],
            [
                *gem.row(StringContainer('Does not have extensions:',
                    TextList('DoNotApplyIfExtensions', delim=',', strip=' ', lstrip='.'), blank_invalid=True
                ))
            ],
            row_parent_folder_size
        ])
        frame_apply_group_if = sg.Frame('Apply Group If', expand_x=True, layout=[
            row_apply_group_if_size
        ])
        frame_action = sg.Frame('Action', expand_x=True, layout=[
            gem.row(Radio('IE', '', {'exclude':'Exclude', 'include':'Include'}))
        ])
        frame_pattern_options = sg.Frame('Pattern Options', expand_x=True, layout=[
            [
                gem.sge(Checkbox('StripExtensions', 'Strip Extensions')),
                gem.sge(Checkbox('WholeName', 'Match Whole Name'))
            ],
            [   
                gem.sge(Checkbox('MatchCase', 'Match Case')),
                gem.sge(Checkbox('UseRegex', 'Use Regex')),
            ],
            [
                gem.sge(Checkbox('MatchAll', 'Match All Patterns'))
            ]
        ])
        layout_patterns = [[sg.Column(gem.layout(TextList('Patterns', empty_text='None (Matches Any)')), expand_y=True)]]
        frame_patterns = sg.Frame('Patterns', expand_x=True, expand_y=True, layout=layout_patterns)
        column_left = sg.Column(expand_y=True, layout=[
            [frame_action],
            [frame_pattern_options],
            [frame_patterns]
        ])
        column_right = sg.Column([
            [frame_apply_to],
            [frame_apply_if],
            [frame_apply_group_if]
        ])
        layout = [
            [column_left, column_right],
            [
                ge_utils.info(gem, info.window, bt='Info'), 
                sg.Push(),
                sg.OK(size=button_size.M),
                sg.Cancel(size=button_size.M)]
        ]
        return layout

    # Events

    def define_events(self):
        super().define_events()
        self.em.bool_events(['OK'], ['Cancel', sg.WIN_CLOSED])

        def event_apply_to_folders(window, event, values, data):
            checked = values[event]
            self.gem['ApplyRecursive'].disable(window, not checked)
            if checked:
                self.gem['ApplyRecursive'].update(window, checked)
        self.em.event_function(self.gem['ApplyToFolders'].keys['Checkbox'], event_apply_to_folders)

    # Data

    def init_window(self, window):
        super().init_window(window)
        self.gem['ApplyRecursive'].disabled = not self.data['ApplyToFolders']

    # Other
