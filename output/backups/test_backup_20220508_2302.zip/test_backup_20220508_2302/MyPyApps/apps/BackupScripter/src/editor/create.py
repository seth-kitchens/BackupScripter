import os
import shutil
import zipapp
import re

from eryx import g as eryx_g
from src.project import g
from src.project.script_data import ScriptDataManagerBS
from eryx.gui.popup import PopupBuilder
from eryx.fs import utils as fs_utils


def create_script(script_data, progress_function):
    update_progress = progress_function
    
    update_progress('Checking Script Destination', 0.3)
    script_file_name = ''.join(script_data['ScriptFileName'])
    script_destination = script_data['ScriptDestination']
    do_make_path = False
    if (not os.path.exists(script_destination)) and (not do_make_path):
        ne_dir = fs_utils.find_nonexistent_dir(script_destination)
        PopupBuilder.T.error().texts((
            'Script destination does not exist.',
            'Path: ' + script_destination,
            'Nonexistent: ' + os.path.basename(ne_dir)
        )).open()
        return False
    script_path = fs_utils.normjoin(script_destination, script_file_name)
    if os.path.exists(script_path):
        if ScriptDataManagerBS.verify_file_is_script(script_path):
            do_continue = PopupBuilder.T.warning().texts((
                'Script file "' + script_file_name + '" already exists. Continue?',
                'Full path: ' + script_path
            )).open()
            if not do_continue:
                return False
        else:
            PopupBuilder.T.error().texts((
                'File "' + script_file_name + ' is not an overwriteable ".pyz" file.',
                'Full path: ' + script_path
            )).open()
            return False

    update_progress('Copying Dependencies', 0.6)
    project_directory = g.constants.project_path
    temp_folder = fs_utils.normjoin(project_directory, '_temp')
    if os.path.exists(temp_folder):
        shutil.rmtree(temp_folder)
    os.mkdir(temp_folder)
    new_main_old_name = 'run_backup.py'
    rel_paths_to_copy = ['src', new_main_old_name] # paths to copy into script TODO automate this with symtable or something to follow imports
    for rel_path in rel_paths_to_copy:
        src = fs_utils.normjoin(project_directory, rel_path)
        dst = fs_utils.normjoin(temp_folder, rel_path)
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        elif os.path.exists(src):
            shutil.copyfile(src, dst)
    rename_from = fs_utils.normjoin(temp_folder, new_main_old_name)
    new_main_path = fs_utils.normjoin(temp_folder, '__main__.py')
    os.rename(rename_from, new_main_path)
    
    # move eryx
    eryx_path = eryx_g.constants.eryx_path
    shutil.copytree(eryx_path, fs_utils.normjoin(temp_folder, 'eryx'))
    lines_to_remove = [
        'from depends import eryx_location',
        'sys.path.append(eryx_location)'
    ]
    with open(new_main_path, 'r') as file_in:
        text = file_in.read()
    lines = text.split('\n')
    for line in lines_to_remove:
        lines.remove(line)
    text = '\n'.join(lines)
    with open(new_main_path, 'w') as file_out:
        file_out.write(text)
    
    # pack data files
    zipfio_data_path = fs_utils.normjoin(temp_folder, g.constants.zipfio_data_rel_path)
    zipfio_data_parent_dir = fs_utils.parent_dir(zipfio_data_path)
    os.makedirs(zipfio_data_parent_dir)
    g.zipfio.zip_files(zipfio_data_path)
    

    update_progress('Compiling Script', 0.9)
    zipapp.create_archive(temp_folder, script_path)
    shutil.rmtree(temp_folder)

    return True