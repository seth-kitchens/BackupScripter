import os

import PySimpleGUI as sg
from eryx.data import units
from eryx.gui import elements as gel
from eryx.gui import window as w
from eryx.gui.event_manager import EventManager
from eryx.gui.ge import utils as ge_utils
from eryx.gui.ge.gem import GuiElementManager
from eryx.gui.popup import PopupBuilder
from eryx.gui.sg import utils as sg_utils
from eryx.gui.sg import wrapped as sgel
from eryx.gui.window import Window
from src.editor.create import create_script
from src.editor.gui.windows.manage_included import WindowManageIncluded
from src.editor.info import window_main as info
from src.project import g
from src.project.fs.vfs import VFSBS as VFS

button_size = sg_utils.button_size

class WindowMain(Window):
    archive_exts = {
            'zip': '.zip'
    }
    def __init__(self, script_manager) -> None:
        self.script_manager = script_manager
        data = script_manager.to_dict()
        self.vfs_static = VFS(data['IncludedItems'], data['ExcludedItems'])
        self.vfs_final = self.vfs_static.clone()
        self.vfs_final.process_matching_groups(data['MatchingGroups'])
        super().__init__('WindowMain', data)
        #self.gem.load_all(self.data)
    
    ### Window

    # Layout

    def get_layout(self):
        gem = self.gem

        menu_def = self.menu_bar.get_def()
        frame_script_file = sgel.FrameColumn('Script File', expand_x=True, layout=[
            gem.row(gel.Filename('ScriptFileName', 'Filename').sg_kwargs_name(expand_x=True)),
            gem.row(gel.Path('ScriptDestination', 'Destination').sg_kwargs_path(expand_x=True)),
            [
                sg.Button('Load Script', key='LoadScript', size=button_size.M),
                sg.Push(),
                sg.Button('Export Script', key='ExportScript', size=button_size.M),
                sg.Button('Export and Quit', key='ExportQuit', size=button_size.L)
            ]
        ])
        frame_backup_file = sgel.FrameColumn('Backup File', expand_x=True, layout=[
            gem.row(gel.Filename('BackupFileName', 'Filename').sg_kwargs_name(expand_x=True)),
            [
                *gem.row(gel.Input('BackupFileNameDate', 'Date Postfix').sg_kwargs_in(expand_x=True)),
                ge_utils.info(gem, info.backup_filename_date)
            ],
            gem.row(gel.Path('BackupDestination', 'Destination').sg_kwargs_path(expand_x=True)),
            [
                *gem.row(gel.Dropdown('ArchiveType', 'Archive Type', list(WindowMain.archive_exts.keys()))),
                sg.Button('Compression Settings', 'CompressionSettings', disabled=True)
            ]
        ])
        frame_backup_settings = sgel.FrameColumn('Backup Settings', expand_y=True, layout=[
            gem.row(gel.Input('MaxBackups', 'Max Backups', type='int', negative_invalid=True)),
            gem.row(gel.InputUnits('BackupRecentAge', 'Recent Age', units.Time, units.Time.DAY, negative_invalid=True)),
            gem.row(gel.InputUnits('BackupOldAge', 'Old Age', units.Time, units.Time.DAY, negative_invalid=True)),
            [sg.VPush()]
        ])
        column_included_labels = sg.Column(pad=0, layout=[
            [sg.Text('Total Folders')],
            [sg.Text('Total Files')]
        ])
        column_included_numbers = sg.Column(element_justification='center', pad=0, layout=[
            gem.row(gel.OutText('TotalFolders')),
            gem.row(gel.OutText('TotalFiles'))
        ])
        column_included = sg.Column(element_justification='left', pad=0, layout=[
            [sg.Text('Included', text_color=g.colors.header)],
            [column_included_labels, column_included_numbers],
            [sg.Column(pad=0, expand_x=True, layout=[[sg.Text('Size'), sg.Push(), *gem.row(gel.OutText('SizeIncluded'))]])]
        ])
        column_excluded_labels = sg.Column(pad=0, layout=[
            [sg.Text('Total Folders')],
            [sg.Text('Total Files')]
        ])
        column_excluded_numbers = sg.Column(element_justification='center', pad=0, layout=[
            gem.row(gel.OutText('TotalFoldersExcluded')),
            gem.row(gel.OutText('TotalFilesExcluded'))
        ])
        column_excluded = sg.Column(pad=0, expand_y=True, layout=[
            [sg.Text('Excluded', text_color=g.colors.header)],
            [column_excluded_labels, column_excluded_numbers],
            [sg.Column(pad=0, expand_x=True, layout=[[sg.Text('Size'), sg.Push(), *gem.row(gel.OutText('SizeExcluded'))]])]
        ])
        frame_ie = sgel.FrameColumn('To Backup', layout=[
            [
                column_included,
                sg.VSeparator(),
                column_excluded
            ],
            [sg.VPush()],
            [
                sg.Push(),
                *gem.row(gel.Radio('IENumbers', text=None, options={'final':'Final', 'static':'Static', 'both':'Static/Final'}).init_data('final')),
                sg.Push()
            ],
            [sg.Button('Manage Included', key='ManageIncluded', expand_x=True)]
        ])
        row_items = [
            frame_ie,
            frame_backup_settings
        ]
        layout = [
            [sg.Menu(menu_def)],
            [frame_script_file],
            [frame_backup_file],
            [row_items]
        ]
        return layout
    
    def define_menu_bar(self):
        m = self.menu_bar
        m['File']['Quit'] = 'Quit'
        m['Editor']['SetDefaults'] = 'Set Defaults'
        m['Editor']['LoadDefaults'] = 'Load Defaults'
        m['Info']['EditorInfo'] = 'Backup Scripter'
    
    # Events

    def define_events(self):
        super().define_events()
        self.em.false_event(sg.WIN_CLOSED)
        self.em.true_event(self.menu_bar.event('Quit'))

        def event_radio_ie_numbers(window, event, values, data):
            self.gem['IENumbers'].pull(values)
            self.refresh_ie(window)
            self.gem['IENumbers'].push(window)
        radio_button_keys = self.gem['IENumbers'].get_button_keys()
        self.em.event_functions(radio_button_keys, event_radio_ie_numbers)

        def event_editor_info(window, event, values, data):
            title = 'Info'
            header = 'Backup Scripter'
            subheader = 'Make custom backup scripts'
            PopupBuilder().ok().title(title).header(header).subheader(subheader).textwrap(info.window).open()
        self.em.event_function(self.menu_bar.event('EditorInfo'), event_editor_info)

        def event_set_defaults(window, event, values, data):
            self.pull(values)
            self.save(data)
            self.script_manager.from_dict(self.data)
            self.script_manager.save_to_file(force_save=True)
        self.em.event_function(self.menu_bar.event('SetDefaults'), event_set_defaults)

        def event_load_defaults(window, event, values, data):
            self.script_manager.load_save_file()
            self.load(self.data)
            self.push(window)
        self.em.event_function(self.menu_bar.event('LoadDefaults'), event_load_defaults)

        def event_compression_type_chosen(window, event, values, data):
            selection = values[self.gem['ArchiveType'].keys['Dropdown']]
            archive_ext = WindowMain.archive_exts[selection]
            self.gem['BackupFileName'].update(window, extension=archive_ext)
        self.em.event_function(self.gem['ArchiveType'].keys['Dropdown'], event_compression_type_chosen)

        def event_create_script(window, event, values, data):
            self.pull(values)
            self.save(self.data)
            success = self.create_script(popup_title='Create Script', auto_close=True)
            return True if success else None
        self.em.event_function('CreateScript', event_create_script)
        
        def event_export_script(window, event, values, data):
            self.pull(values)
            self.save(self.data)
            self.create_script(popup_title='Export Script', auto_close=False)
        self.em.event_function('ExportScript', event_export_script)
        
        def event_load_script(window, event, values, data):
            script_to_load = sg_utils.browse_file(window)
            if not script_to_load:
                return
            sm = self.script_manager
            sm.load_pyz(script_to_load)
            name = os.path.basename(script_to_load)
            i = name.rfind('.')
            sm['ScriptFileName'] = [name[:i], name[i:]]
            self.load(self.data)
            self.push(window)
        self.em.event_function('LoadScript', event_load_script)
        
        def event_compression_settings(window, event, values, data):
            pass
        self.em.event_function('CompressionSettings', event_compression_settings)

        def event_manage_included(window, event, values, data):
            window_manage_included = WindowManageIncluded(self.data, self.vfs_static)
            rv = window_manage_included.open()
            if not rv:
                return
            self.data.update(window_manage_included.get_data())
            self.vfs_static.copy_from_vfs(window_manage_included.vfs_static)
            self.vfs_final.copy_from_vfs(self.vfs_static)
            self.vfs_final.process_matching_groups(self.data['MatchingGroups'])
            self.refresh_ie(window)
        self.em.event_function('ManageIncluded', event_manage_included)

    # Data

    def save(self, data):
        super().save(data)
        data['IncludedItems'], data['ExcludedItems'] = self.vfs_static.make_ie_lists()
    def load(self, data):
        data = self.script_manager.to_dict()
        super().load(data)
        self.vfs_static.remove_all()
        self.vfs_static.build_from_ie_lists(data['IncludedItems'], data['ExcludedItems'])
        self.vfs_final.copy_from_vfs(self.vfs_static)
        self.vfs_final.process_matching_groups(data['MatchingGroups'])
    def push(self, window):
        super().push(window)
        self.refresh_ie(window)
    def init_window(self, window):
        super().init_window(window)
        self.refresh_ie(window)

    ### WindowMain

    def create_script(self, popup_title='', auto_close=True):
        self.script_manager.from_dict(self.data)
        self.script_manager.set_read_only()
        popup_progress = w.ProgressWindow('Progress', header='Creating Script')
        progress_function = popup_progress.get_progress_function()
        popup_progress.open()
        try:
            success = create_script(self.script_manager, progress_function)
        except Exception as e:
            success = False
            PopupBuilder().texts(('Script Creation Failed!', 'Exception: ' + str(e))).title(popup_title).ok().open()
            raise e
        popup_progress.close()

        if success:
            popup = PopupBuilder().text('Script Created Successfully').title(popup_title).ok()
            if auto_close:
                popup.auto_ok()
            popup.open()
        self.script_manager.set_read_only(False)
        return success
    
    def refresh_ie(self, window):
        data_static = {}
        data_final = {}
        self.vfs_static.save_data_to_dict(data_static)
        self.vfs_final.save_data_to_dict(data_final)

        #rf_static = data_static['RootFileCount']
        #rF_static = data_static['RootFolderCount']
        if_static = data_static['IncludedFileCount']
        iF_static = data_static['IncludedFolderCount']
        isz_static = units.Bytes(data_static['IncludedSize'], units.Bytes.B).get_best(1, 0.1)
        ef_static = data_static['ExcludedFileCount']
        eF_static = data_static['ExcludedFolderCount']
        esz_static = units.Bytes(data_static['ExcludedSize'], units.Bytes.B).get_best(1, 0.1)

        #rf_final = data_final['RootFileCount']
        #rF_final = data_final['RootFolderCount']
        if_final = data_final['IncludedFileCount']
        iF_final = data_final['IncludedFolderCount']
        isz_final = units.Bytes(data_final['IncludedSize'], units.Bytes.B).get_best(1, 0.1)
        ef_final = data_final['ExcludedFileCount']
        eF_final = data_final['ExcludedFolderCount']
        esz_final = units.Bytes(data_final['ExcludedSize'], units.Bytes.B).get_best(1, 0.1)

        def sbs(a, b):
            return str(a) + ' / ' + str(b)
        
        mode = self.gem['IENumbers'].get_selected_value()
        if mode == 'static':
            #rf = rf_static
            #rF = rF_static
            inf = if_static
            iF = iF_static
            isz = isz_static
            ef = ef_static
            eF = eF_static
            esz = esz_static
        elif mode == 'final':
            #rf = rf_final
            #rF = rF_final
            inf = if_final
            iF = iF_final
            isz = isz_final
            ef = ef_final
            eF = eF_final
            esz = esz_final
        elif mode == 'both':
            #rf = sbs(rf_static, rf_final)
            #rF = sbs(rF_static, rF_final)
            inf = sbs(if_static, if_final)
            iF = sbs(iF_static, iF_final)
            isz = sbs(isz_static, isz_final)
            ef = sbs(ef_static, ef_final)
            eF = sbs(eF_static, eF_final)
            esz = sbs(esz_static, esz_final)

        #window['OutRootFiles'](rf)
        #window['OutRootFolders'](rF)
        window['OutTotalFiles'](inf)
        window['OutTotalFolders'](iF)
        window['OutSizeIncluded'](isz)

        window['OutTotalFilesExcluded'](ef)
        window['OutTotalFoldersExcluded'](eF)
        window['OutSizeExcluded'](esz)
