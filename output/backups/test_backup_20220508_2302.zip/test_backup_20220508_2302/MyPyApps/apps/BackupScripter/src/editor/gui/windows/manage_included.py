import PySimpleGUI as sg
from src.editor.info import window_manage_included as info
from eryx.fs.vfs_explorer import VFSExplorer
from src.editor.gui.elements import VFSExplorerViewBS
from src.project.fs.vfs import VFSBS as VFS
from eryx.gui import elements as gel
from src.editor.gui import elements as gel_bs
from eryx.gui.event_manager import EventManager
from eryx.gui.ge.gem import GuiElementManager
from eryx.gui.popup import Popups
from eryx.gui.window import Window
from eryx.misc import debug_utils
from eryx.gui.ge import utils as ge_utils
from eryx.gui.sg import utils as sg_utils, wrapped as sgel

button_size = sg_utils.button_size


class WindowManageIncluded(Window):
    def __init__(self, data:dict, vfs_static:VFS) -> None:
        self.vfs_static = vfs_static.clone()
        self.vfs_explorer = VFSExplorer(self.vfs_static, data.copy())
        super().__init__('WindowManageIncluded', data)

    # Layout

    def get_layout(self):
        gem = self.gem
        frame_iepatterns = sgel.FrameColumn('Matching Groups', expand_x=True,
            layout=gem.layout(gel_bs.MatchingGroupsList('MatchingGroups', self.vfs_static)))
        frame_explorer = sgel.FrameColumn('Static Inclusion',
            layout=gem.layout(VFSExplorerViewBS('IEExplorer', self.vfs_explorer)))
        row_system = [
            sg.Button('Return', size=10),
            ge_utils.info(gem, info.window, bt='Info', header='Manage Included', sg_kwargs={'size': 12}),
        ]
        layout = [
            row_system,
            [frame_explorer],
            [frame_iepatterns]
        ]
        return layout
    
    # Events

    def define_events(self):
        super().define_events()
        self.em.true_event('Return')
        self.em.false_event(sg.WIN_CLOSED)
        self.em.save_function(self.vfs_static.save_data_to_dict, self.data)
    
        def event_preview_here(window, event, values, data):
            mglist = self.gem['MatchingGroups']
            mgs = mglist.get_through_selection()
            if not mgs:
                return
            self.preview_match_groups(mgs)
        self.em.event_function(self.gem['MatchingGroups'].keys['PreviewHere'], event_preview_here)

        def event_preview_all(window, event, values, data):
            mglist = self.gem['MatchingGroups']
            mgs = mglist.get_pairs()
            if not mgs:
                return
            self.preview_match_groups(mgs)
        self.em.event_function(self.gem['MatchingGroups'].keys['PreviewAll'], event_preview_all)

        def event_resolve_here(window, event, values, data):
            mglist = self.gem['MatchingGroups']
            mgs = mglist.get_through_selection()
            if not mgs:
                return
            if not Popups.confirm('Resolve up to here? This group and all before it will be processed into static inclusion.'):
                return
            self.vfs_static.process_matching_groups(mgs)
            mglist.remove_through_selection()
            self.gem.push_all(window)
        self.em.event_function(self.gem['MatchingGroups'].keys['ResolveHere'], event_resolve_here)

        def event_resolve_all(window, event, values, data):
            mglist = self.gem['MatchingGroups']
            mgs = mglist.get_pairs()
            if not mgs:
                return
            if not Popups.confirm('Resolve all? All groups will be processed into static inclusion.'):
                return
            self.vfs_static.process_matching_groups(mgs)
            mglist.remove_all()
            self.gem.push_all(window)
        self.em.event_function(self.gem['MatchingGroups'].keys['ResolveAll'], event_resolve_all)        
    
    # Data

    # Other

    def preview_match_groups(self, match_groups):
        vfs_temp = VFS()
        vfs_temp.copy_from_vfs(self.vfs_static)
        vfs_temp.process_matching_groups(match_groups)

        data = {}
        gem = GuiElementManager()
        vfs_explorer = VFSExplorer(vfs_temp, data)
        gem.add_ge(VFSExplorerViewBS('TempExplorerView', vfs_explorer))
        column_explorer_view = sg.Column(gem['TempExplorerView'].get_layout_explorer())
        layout = [
            [column_explorer_view],
            [sg.HSeparator()],
            [sg.Push(), sg.OK(size=18), sg.Push()]
        ]
        em = gem.prepare_event_manager(data)
        em.bool_events(['OK'], [sg.WIN_CLOSED])
        window = sg.Window('Preview', layout, finalize=True)
        #em.handle_event_function(gem['TempExplorerView'].handle_event)
        #vfs_explorer.refresh_current_dir()
        em.event_loop(window)
