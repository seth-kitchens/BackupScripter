from src.backup.run import run

# TODO add option to edit scripts with editor (editor will have to be linked, added to path, etc)

def app(script_manager):
    run(script_manager)
