import PySimpleGUI as sg
from src.editor.gui.windows.main import WindowMain
from src.project.g import style

def app(script_manager):
    sg.theme(style.sg_theme)
    window_main = WindowMain(script_manager)
    rv = window_main.open()
    return rv