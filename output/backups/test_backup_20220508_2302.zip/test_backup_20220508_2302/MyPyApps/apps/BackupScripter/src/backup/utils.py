from datetime import datetime

from eryx.fs import utils as fs_utils

def is_file_backup(filename:str, backup_basename:str, backup_date_string:str, backup_extension:str):
    if not filename.startswith(backup_basename):
        return False
    fn = filename[len(backup_basename):]
    if backup_extension:
        if not fn.endswith(backup_extension):
            return False
        fn = fn[:-1 * len(backup_extension)]

    min_len = len(fs_utils.process_date_string(backup_date_string, do_lstrip=True, dt=datetime(1, 1, 1, 0, 0, 0)))
    if len(fn) < min_len:
        return False
    
    max_len = len(fs_utils.process_date_string(backup_date_string, do_lstrip=False, dt=datetime(1111, 11, 11, 11, 11, 11)))
    if len(fn) > max_len:
        return False
    
    return True
