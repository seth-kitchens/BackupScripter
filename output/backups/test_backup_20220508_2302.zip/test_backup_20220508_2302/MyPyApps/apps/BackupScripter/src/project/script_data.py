from eryx.script.script_data import ScriptDataManager, ScriptVariable, ScriptDataGroup, ScriptMetadataGroup
from src.project import g

class ScriptDataManagerBS(ScriptDataManager):
    def __init__(self):
        super().__init__(g.constants.script_data_file, g.zipfio)
        SV = ScriptVariable
        
        self.define_variables([
            ScriptMetadataGroup('Script File', [
                SV('ScriptFileName', ['backup_script', '.pyz']),
                SV('ScriptDestination', 'C:\\Main\\Python\\MyPyApps\\apps\\BackupScripter\\_scripts')
            ]),
            ScriptDataGroup('Backup File', [
                SV('BackupFileName', ['backup', '.zip'], info='fields: [name][ext]'),
                SV('BackupFileNameDate', '_YYYYMMDD_HHmm', info='Replaces any YYYY/MM/DD/HH/hh/mm/SV/UU in date field with date/time'),
                SV('BackupDestination', 'C:\\Main\\Python\\MyPyApps\\apps\\BackupScripter\\_backups')
            ]),
            ScriptDataGroup('Static Inclusion', [
                SV('IncludedItems', []),
                SV('ExcludedItems', [])
            ]),
            ScriptDataGroup('Compression', [
                SV('ArchiveType', '')
            ]),
            ScriptDataGroup('Backup Settings', [
                SV('MaxBackups', None),
                SV('BackupOldAge', None),
                SV('BackupRecentAge', None)
            ]),
            ScriptDataGroup('Dynamic Inclusion', [
                SV('MatchingGroups', {})
            ])
        ])
        self.load_save_file()
