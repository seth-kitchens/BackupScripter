from eryx.project.settings_manager import SettingsManager
from eryx import g as eryx_g
from eryx.fs import utils as fs_utils
from eryx.fs.zipfio import ZipFIO
from data.project.zipfio_data import zipfio_data

_project_path = 'C:\\Main\\Python\\MyPyApps\\apps\\BackupScripter'
def _proj(path):
    return fs_utils.normjoin(_project_path, path)
class constants(eryx_g.constants):
    project_path = _project_path

    settings_file = _proj('data/project/settings.json')
    script_data_file = _proj('data/project/script_data.json')
    temp_folder = _proj('temp')
    initial_script = _proj('backup.py') # loaded at start
    template_script = _proj('backup.py')
    
    zipfio_data_rel_path = 'data/project/zipfio_data.py'
    zipfio_paths = set([]) # defined after class

    class flags:
        DEBUG = '--debug'
        DBGCMD = '--dbgcmd'
        EDITOR = '--editor'
        BACKUP = '--backup'
        GETDATA = '--getdata'
gc = constants
gc.zipfio_paths.update([
    gc.settings_file,
    gc.script_data_file
])

class variables(eryx_g.variables):
    pass
gv = variables

zipfio = ZipFIO(gc.zipfio_paths, zipfio_data)
sm = settings = settings_manager = eryx_g.sm
sm.set_zipfio(zipfio)

# Values here will overwrite eryx/g.py's settings, but be overwritten by the settings file
bs_settings = {}
sm.load_value_dict(bs_settings)
sm.load_file(gc.settings_file)

class style(eryx_g.style):
    pass
colors = style.colors
