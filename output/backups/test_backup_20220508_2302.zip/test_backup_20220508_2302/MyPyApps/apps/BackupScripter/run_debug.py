import os
import sys

if '--editor' in sys.argv:
    action = '--editor'
elif '--backup' in sys.argv:
    action = '--backup'

command = 'start cmd /k python . '
command += action
command += ' --debug --dbgcmd ^&^& exit'
os.system(command)