import PySimpleGUI as sg

info_text = '\n'.join([
    "Real Wage: Calculate a wage adjusted for all time and costs.",
    "  There are other important things to consider about a job, but this will",
    "  provide a better number to compare with than wage alone.",
    "",
    "Gray indicates fields that generally don't change from job to job",
    "[CALC_ALL] will calculate all in the order: MPG->CM->CC->RW",
    "",
    "Notes",
    "  - Effective city MPG is currently calculated as 65% of base city mpg",
    "  - Effective highway MPG is approximated with a linear piecewise function",
    "      and is inaccurate above 80mph or so. Based on mpgforspeed.com",
    "  - Income tax is currently approximated as 12%",
    "  - [CALC_ALL] uses the unrounded numbers, so it might result in a",
    "      slightly different value",
    "",
    "TODO",
    "  - Add field for free time (breaks) and free time value (0.5)",
    "  - Add [Copy as CSV] Button, as a column if possible"
])

def minutes_to_hours(minutes):
    return minutes / 60

def apply_weekly_income_tax(net_profit_weekly):
    net_profit_taxed = net_profit_weekly * 0.88
    return net_profit_taxed

def calc_mpg_multiplier_city(average_speed):
    return 0.65

def calc_mpg_multiplier_highway(average_speed):
    # approximation based on mpgforspeed.com (fueleconomy.gov)
    #   x<27     -> y=x*0.2+0.45
    #   27<=x<56 -> y=x*0.02+0.89
    #   56<=x<66 -> y=1.385-x*0.007
    #   66<=x    -> y=1.6-x*0.011
    if (average_speed < 27):
        return average_speed * 0.2 + 0.45
    elif (average_speed < 56):
        return average_speed * 0.002 + 0.89
    elif (average_speed < 66):
        return 1.385 - (average_speed * 0.007)
    else:
        return 1.6 - (average_speed * 0.011)

def calc_effective_mpg(base_mpg_city, base_mpg_highway, average_speed_city,
    average_speed_highway):
    effective_mpg_city = base_mpg_city * calc_mpg_multiplier_city(average_speed_city)
    effective_mpg_highway = base_mpg_highway * calc_mpg_multiplier_highway(average_speed_highway)
    return effective_mpg_city, effective_mpg_highway

def calc_commute_cost(gas_cost, mpg_city, mpg_highway, commute_distance, ratio_highway):
    miles_highway = commute_distance * ratio_highway
    miles_city = commute_distance * (1 - ratio_highway)
    gallons_spent = (miles_city / mpg_city) + (miles_highway / mpg_highway)
    return gallons_spent * gas_cost

def calc_commute_minutes(commute_distance, ratio_highway, average_speed_city, average_speed_highway):
    distance_highway = commute_distance * ratio_highway
    distance_city = commute_distance - distance_highway
    time_highway = distance_highway / average_speed_highway
    time_city = distance_city / average_speed_city
    total_hours = time_highway + time_city
    return total_hours * 60

def calc_real_wage(hourly_wage, hours_weekly, ot_hours_weekly,
    commute_minutes, commute_cost, shifts_per_week, pre_work_minutes,
    during_work_minutes, post_work_minutes, other_costs_weekly):

    regular_wages_weekly = hourly_wage * hours_weekly
    ot_wages = 0.5 * hourly_wage * ot_hours_weekly
    commute_cost_weekly = commute_cost * 2 * shifts_per_week
    total_cost_weekly = commute_cost_weekly + other_costs_weekly
    gross_income_weekly = regular_wages_weekly + ot_wages
    net_income_weekly = gross_income_weekly - total_cost_weekly

    extra_hours_per_day = minutes_to_hours(
        pre_work_minutes + during_work_minutes + post_work_minutes + commute_minutes * 2)
    total_hours_weekly = hours_weekly + (extra_hours_per_day * shifts_per_week)

    real_wage = net_income_weekly / total_hours_weekly
    return real_wage, total_hours_weekly, total_cost_weekly, gross_income_weekly

def info_popup(message):
    layout = [
        [sg.Text(message)],
        [sg.Button("OK")]
    ]
    window = sg.Window("Info", layout)
    while True:
        event, values = window.read()
        if event == "OK" or event == sg.WIN_CLOSED:
            break
    window.close()

def event_loop():
    color_consistent = "#BBBBBB"
    section_fuel_economy = [
        [sg.Text("Base MPG City", text_color=color_consistent), sg.In(key="BaseMpgCity", default_text="32")],
        [sg.Text("Base MPG Highway", text_color=color_consistent), sg.In(key="BaseMpgHighway", default_text="41")],
        [sg.Text("Average Speed City"), sg.In(key="AverageSpeedCity", default_text="50")],
        [sg.Text("Average Speed Highway"), sg.In(key="AverageSpeedHighway", default_text="70")]
    ]
    section_commute_cost = [
        [sg.Text("Gas Cost", text_color=color_consistent), sg.In(key="GasCost", default_text="4.09")],
        [sg.Text("Effective MPG City", text_color=color_consistent), sg.In(key="EffectiveMpgCity", default_text="21"), sg.Button("CALC_MPG")],
        [sg.Text("Effective MPG Highway", text_color=color_consistent), sg.In(key="EffectiveMpgHighway", default_text="34")],
        [sg.Text("Commute Distance"), sg.In(key="CommuteDistance", default_text="7.2")],
        [sg.Text("Commute Ratio Highway"), sg.In(key="RatioHighway", default_text="0")]
    ]
    section_real_wage_input = [
        [sg.Text("Hourly Wage"), sg.In(key="HourlyWage", default_text="10.50")],
        [sg.Text("Average Hours"), sg.In(key="AverageHours", default_text="21.0")],
        [sg.Text("Average OT Hours"), sg.In(key="AverageOtHours", default_text="0")],
        [sg.Text("Commute Minutes (One-way)"), sg.In(key="CommuteMinutes", default_text="11.0"), sg.Button("CALC_CM")],
        [sg.Text("Commute Cost (One-way)"), sg.In(key="CommuteCost", default_text="1.4"), sg.Button("CALC_CC")],
        [sg.Text("Shifts per Week"), sg.In(key="ShiftsPerWeek", default_text="4")],
        [sg.Text("Pre-Work Minutes"), sg.In(key="PreWorkMinutes", default_text="15")],
        [sg.Text("During-Work Minutes"), sg.In(key="DuringWorkMinutes", default_text="0")],
        [sg.Text("Post-Work Minutes"), sg.In(key="PostWorkMinutes", default_text="5")],
        [sg.Text("Other Costs per Week"), sg.In(key="OtherCostsWeekly", default_text="0")]
    ]
    section_real_wage_output = [
        [sg.Text("Real Wage (Before Tax)"), sg.Multiline(key="OutputRealWage", no_scrollbar=True)],
        [sg.Text("Weekly Hours Spent"), sg.Multiline(key="OutputTotalHours", no_scrollbar=True)],
        [sg.Text("Weekly Total Cost"), sg.Multiline(key="OutputTotalCost", no_scrollbar=True)],
        [sg.Text("Weekly Net Profit (After Tax)"), sg.Multiline(key="OutputNetProfitAfterTax", no_scrollbar=True)],
        [sg.Button("CALC_RW")]
    ]
    section_real_wage = [
        sg.Column(section_real_wage_input),
        sg.VSeparator(),
        sg.Column(section_real_wage_output)
    ]
    section_system = [
        [sg.Button("QUIT"), sg.Button("INFO"), sg.Button("CALC_ALL")]
    ]
    layout = [
        [sg.Text("Fuel Economy", text_color="gold")],
        [section_fuel_economy],
        [sg.HSeparator()],
        [sg.Text("Commute Cost", text_color="gold")],
        [section_commute_cost],
        [sg.HSeparator()],
        [sg.Text("Real Wage", text_color="gold")],
        [section_real_wage],
        [sg.HSeparator()],
        [section_system]
    ]

    # Create the window
    window = sg.Window("Real Wage Calculator", layout)

    # Create an event loop
    while True:
        event, values = window.read()

        def calc_rw():
            real_wage, total_hours, total_cost, gross_income = calc_real_wage(
                hourly_wage=float(values["HourlyWage"]),
                hours_weekly=float(values["AverageHours"]),
                ot_hours_weekly=float(values["AverageOtHours"]),
                commute_minutes=float(values["CommuteMinutes"]),
                commute_cost=float(values["CommuteCost"]),
                shifts_per_week=float(values["ShiftsPerWeek"]),
                pre_work_minutes=float(values["PreWorkMinutes"]),
                during_work_minutes=float(values["DuringWorkMinutes"]),
                post_work_minutes=float(values["PostWorkMinutes"]),
                other_costs_weekly=float(values["OtherCostsWeekly"])
            )
            window["OutputRealWage"].update(round(real_wage, 2))
            window["OutputTotalHours"].update(round(total_hours, 1))
            net_profit_taxed = apply_weekly_income_tax(gross_income) - total_cost
            window["OutputNetProfitAfterTax"].update(round(net_profit_taxed, 2))
            window["OutputTotalCost"].update(round(total_cost, 2))
        
        def calc_cc():
            commute_cost = calc_commute_cost(
                gas_cost=float(values["GasCost"]),
                mpg_city=float(values["EffectiveMpgCity"]),
                mpg_highway=float(values["EffectiveMpgHighway"]),
                commute_distance=float(values["CommuteDistance"]),
                ratio_highway=float(values["RatioHighway"])
            )
            window["CommuteCost"].update(round(commute_cost, 2))
            values["CommuteCost"] = commute_cost

        def calc_cm():
            commute_minutes = calc_commute_minutes(
                commute_distance=float(values["CommuteDistance"]),
                ratio_highway=float(values["RatioHighway"]),
                average_speed_city=float(values["AverageSpeedCity"]),
                average_speed_highway=float(values["AverageSpeedHighway"])
            )
            window["CommuteMinutes"].update(round(commute_minutes, 2))
            values["CommuteMinutes"] = commute_minutes
        
        def calc_mpg():
            effective_mpg_city, effective_mpg_highway = calc_effective_mpg(
                base_mpg_city=float(values["BaseMpgCity"]),
                base_mpg_highway=float(values["BaseMpgHighway"]),
                average_speed_city=float(values["AverageSpeedCity"]),
                average_speed_highway=float(values["AverageSpeedHighway"])
            )
            window["EffectiveMpgCity"].update(round(effective_mpg_city, 2))
            window["EffectiveMpgHighway"].update(round(effective_mpg_highway, 2))
            values["EffectiveMpgCity"] = effective_mpg_city
            values["EffectiveMpgHighway"] = effective_mpg_highway

        try:
            if event == "CALC_RW":
                calc_rw()
            elif event == "CALC_CC":
                calc_cc()
            elif event == "CALC_CM":
                calc_cm()
            elif event == "CALC_MPG":
                calc_mpg()
            elif event == "CALC_ALL":
                calc_mpg()
                calc_cm()
                calc_cc()
                calc_rw()
            elif event == "INFO":
                info_popup(info_text)
            elif event == "QUIT" or event == sg.WIN_CLOSED:
                break
        except ValueError:
            print("Error: Bad Value")

    window.close()

def main():
    event_loop()
    return