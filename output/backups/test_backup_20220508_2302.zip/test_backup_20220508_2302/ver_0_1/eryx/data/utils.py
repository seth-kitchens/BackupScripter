from typing import Any

def flip_pairs_in_list(pair_list: list[tuple[Any, Any]]):
    l = []
    for pair in pair_list:
        l.append((pair[1], pair[0]))
    return l
