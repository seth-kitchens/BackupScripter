from eryx.misc import utils as misc_utils
from eryx.project.settings_manager import SettingsManager

class constants:
    eryx_path = 'C:\\Main\\Python\\Lib\\eryxlib\\ver_0_1\\eryx'
gc = constants

class variables:
    pass
gv = variables

sm = settings = settings_manager = SettingsManager()
eryx_settings = {}
sm.load_value_dict(eryx_settings)

class style:
    name = 'py'
    sg_theme = 'DarkBlue3'
    class colors:
        error = 'red'
        warning = 'orange'
        header = 'gold'
        valid = 'white'
        invalid = 'lightgray'
    def load_style(d_style:dict):
        def load(name):
            misc_utils.update_member(style, d_style, name)
        load('name')
        load('sg_theme')
        if 'colors' in d_style:
            def load_color(name):
                misc_utils.update_member(style.colors, d_style['colors'], name)
            load_color('error')
            load_color('warning')
            load_color('header')
            load_color('valid')
            load_color('invalid')
    class styles:
        py = {
            'sg_theme': 'DarkBlue3',
            'colors': {
                'error': 'red',
                'warning': 'orange',
                'header': 'gold',
                'valid': 'white',
                'invalid': 'lightgray'
            }
        }
        boring = {
            'sg_theme': 'Default1',
            'colors': {
                'error': 'red',
                'warning': 'orange',
                'header': 'black'
            }
        }
colors = style.colors
