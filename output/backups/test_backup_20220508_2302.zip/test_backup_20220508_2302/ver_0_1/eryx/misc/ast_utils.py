import os.path
import ast

from eryx.fs import utils as fs_utils

def file_to_ast(path):
    text = fs_utils.file_to_string(path)
    return ast.parse(text)

# Import, Names, Attributes

def attr_name_to_str(ast_node):
    parts=[]
    node = ast_node
    while True:
        if isinstance(node, ast.Attribute):
            parts.insert(0, node.attr)
        elif isinstance(node, ast.Name):
            parts.insert(0, node.id)
            break
        elif isinstance(node, ast.Constant):
            parts.insert(0, node.value)
            break
        elif isinstance(node, ast.Call):
            parts.insert(0, attr_name_to_str(node.func))
            break
        node = node.value
    return '.'.join(parts)

def str_to_attr_name(s):
    parts=s.split('.')
    node = ast.Name(id=parts.pop(0))
    while parts:
        attr = parts.pop(0)
        value = node
        node = ast.Attribute(value=value, attr=attr)
    return node

# Node/Module Operations

def global_assigns_to_dict(text):
    ast_tree = ast.parse(text)
    # traverse only top-level node's children, copying assignments
    d = {}
    for node in ast_tree.body:
        if isinstance(node, ast.Assign):
            v = ast.literal_eval(node.value)
            for target in node.targets:
                k = ast.unparse(target)
                d[k] = v
    return d

# Create

def create_module(body=[], type_ignores=[]):
    return ast.Module(body=body, type_ignores=type_ignores)

def create_assign(variable, val, val_type='constant'):
    targets = [
        ast.Name(id=variable, ctx=ast.Store())
    ]
    if val_type == 'constant':
        value = ast.Constant(value=val)
    elif val_type == 'name':
        value = ast.Name(id=val)
    return ast.Assign(targets=targets, value=value)

def create_assign_name(variable, val):
    return create_assign(variable, val, val_type='name')

def create_class_def(class_name, body):
    cd_name = class_name
    cd_bases = []
    cd_keywords = []
    cd_body = body
    cd_decorator_list = []

    return ast.ClassDef(name=cd_name, bases=cd_bases, keywords=cd_keywords, body=cd_body, decorator_list=cd_decorator_list)

# Other
