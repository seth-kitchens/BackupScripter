"misc" folder
---

This folder is for things that have no better place.

Do consider finding these orphan files a loving home as soon
as possible. Maybe make one for them? They are cold and lonely.

Elsewhere, there should not be more than one 'utils' file per
directory, but here it is appropriate until a better place exists.