from math import floor, log10
from typing import Any

from eryx.misc import debug_utils as ddd

# move functions here to a better location if there is one, and at least several functions belonging there

# based on https://stackoverflow.com/questions/3410976
def round_to_n(x, n):
    if x < 0:
        return -round_to_n(-x, n)
    if x == 0:
        return 0
    return round(x, -int(floor(log10(x))) + (n - 1))

def update_member(obj, d, name):
    if name in d and name in dir(obj):
        obj.__dict__[name] = d[name]