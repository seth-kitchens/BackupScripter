import json

"""
Settings:

'setting': A data structure of at least a name and value, optionally info

'entry': A dict representation of one setting
'entry group': a (setting_name->entry) dict of settings
'entry dict': a (group_name->entry_group) dict

'value': The value of one setting
'value group': a (setting_name->value) dict of settings
'value dict': a (group_name->value_group) dict

settings are stored as entries in the json settings file

Intented precedence for a given child class:
- child > base > all  (This is determined by the order of pull_groups() calls and params)
- json > project > eryx   (This is determined by order of SettingsManager.load...() calls)

Below is an example of intended structure for this settings api, with many example settings to
show precedence.

eryx/g.py
    eryx_settings = {
        'all': {
            'a': 'a_all_eryx',
            'b': 'b_all_eryx',
            'e': 'e_all_eryx'},
        'base': {
            'c': 'c_base_eryx'
            'd': 'd_base_eryx',
            'e': 'e_base_eryx',
            'f': 'f_base_eryx',
            'g': 'g_base_eryx'},
        'child': {
            'd': 'd_child_eryx',
            'f': 'f_child_eryx',
            'h': 'h_child_eryx'}}
    settings_manager = SettingsManager()
    settings_manager.load_value_dict(eryx_settings)
project/g.py
    project_settings = {
        'all': {
            'a': 'a_all_project',
            'c': 'c_all_project'},
        'base': {
            'd': 'd_base_project,
            'e': 'e_base_project},
        'child': {
            'f': 'f_child_project
        }
    }
    settings_manager = eryx.g.settings_manager
    settings_manager.load_value_dict(project_settings)
    settings_manager.set_zipfio(zipfio)
    settings_manager.load_file(settings_file)
project/settings.json
    {
        "all": {
            "a": "a_all_json"
        },
        "base": {
            "g": "g_base_json"
            "h": "h_base_json"
        }
    }
eryx/base.py
    Base.__init__():
        settings = {}
        g.settings_manager.pull(self.settings, ['all', 'base'])
eryx/child.py
    Child.__init__():
        g.settings_manager.pull(self.settings, ['child']) # Not necessary if no specific settings, but okay
Now, after child.__init__ is called, child.settings is {
    'a': 'a_all_json',
    'b': 'b_all_eryx',
    'c': 'c_base_eryx',
    'd': 'd_child_eryx',
    'e': 'e_base_project',
    'f': 'f_child_project',
    'g': 'g_base_json',
    'h': 'h_child_eryx'
}"""

class Setting:
    def __init__(self):
        self.name = ''
        self.value = ''
        self.info = ''
    def to_entry(self):
        d = {'value': self.value}
        if self.info:
            d['info'] = self.info
        return d
    def from_entry(name, entry):
        setting = Setting()
        setting.name = name
        setting.value = entry['value']
        setting.info = entry.get('info', '')
        return setting

class SettingsGroup:
    def __init__(self, settings_manager, entry_group=None, value_group=None):
        self.sm = settings_manager
        self.settings = {}
        if entry_group != None:
            self.load_entry_group(entry_group)
        elif value_group != None:
            self.load_value_group(value_group)
    def __getitem__(self, name):
        return self.settings[name].value
    def __setitem__(self, name, value):
        self.set(name=name, value=value)
    def save_entry_group(self, d):
        for name, setting in self.settings.items():
            d[name] = setting.to_entry()
    def save_value_group(self, d):
        for name, setting in self.settings.items():
            d[name] = setting.value
    def load_value_group(self, d):
        for setting_name, value in d.items():
            if setting_name in self.settings:
                self.settings[setting_name] = value
            else:
                setting = Setting()
                setting.value = value
                self.settings[setting_name] = setting
    def load_entry_group(self, d):
        for setting_name, entry in d.items():
            if setting_name in self.settings:
                setting = self.settings[setting_name]
                setting.value = entry.value
                setting.info = entry.get('info', setting.info)
            else:
                self.settings[setting_name] = Setting.from_entry(setting_name, entry)
    def set(self, name, value=None, info=None):
        if value != None:
            self.settings[name].value = value
        if info != None:
            self.settings[name].info = info
    def info(self, name, text=None):
        if text != None:
            self.set(name, info=text)
        return self.settings[name].info

class SettingsManager:
    def __init__(self, zipfio=None):
        self.zipfio = zipfio
        self.settings_groups = {}
    def __getitem__(self, group_name):
        return self.settings_groups[group_name]
    def set_zipfio(self, zipfio):
        self.zipfio = zipfio
    def load_value_dict(self, d):
        for group_name, value_group in d.items():
            if group_name in self.settings_groups:
                self.settings_groups[group_name].load_value_group(value_group)
            else:
                self.settings_groups[group_name] = SettingsGroup(self, value_group=value_group)
    def load_entry_dict(self, d):
        for group_name, entry_group in d.items():
            if group_name in self.settings_groups:
                self.settings_groups[group_name].load_entry_group(entry_group)
            else:
                self.settings_groups[group_name] = SettingsGroup(self, entry_group=entry_group)
    def load_file(self, path):
        if self.zipfio == None:
            raise RuntimeError("ZipFIO is None, can't load settings from file.")
        d = json.loads(self.zipfio.read_file(path))
        self.load_entry_dict(d)
    def save_to_value_dict(self, d=None):
        if d == None:
            d = {}
        for group_name, group in self.settings_groups.items():
            d[group_name] = {}
            group.save_value_group(d[group_name])
    def save_to_entry_dict(self, d=None):
        if d == None:
            d = {}
        for group_name, group in self.settings_groups.items():
            d[group_name] = {}
            group.save_entry_group(d[group_name])
        return d
    def save_to_file(self, path):
        if self.zipfio == None:
            raise RuntimeError("ZipFIO is None, can't save settings to file")
        d = self.save_to_entry_dict()
        if not d:
            raise RuntimeError('d is empty')
        self.zipfio.write_file(path, json.dumps(d, indent=4))
    def pull(self, value_dict, group_names):
        for group_name in group_names:
            if group_name in self.settings_groups:
                group = self.settings_groups[group_name]
                for setting_name, setting in group.settings.items():
                    value_dict[setting_name] = setting.value
    def update_dicts(self, d_lib, d_project):
        d_loaded = self.get_dict()
        SettingsManager._update_dict(d_lib, d_project)
        SettingsManager._update_dict(d_lib, d_loaded)
        SettingsManager._update_dict(d_project, d_lib)
    def _update_dict(d_to:dict, d_from:dict):
        """Update a dict with settings values, traversing dicts if they already exist."""
        for k, v in d_from.items():
            if k in d_to and isinstance(v, dict):
                SettingsManager.update_dict(d_to[k], v)
            else:
                d_to[k] = v
    def get_dict(self):
        d = {}
        for group_name, group in self.settings_groups.items():
            d[group_name] = {}
            for setting_name, setting in group.settings.items():
                d[group_name][setting_name] = setting.value
        return d