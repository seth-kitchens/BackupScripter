import json

class ZipFIO:
    def __init__(self, paths, zipfio_data):
        self.paths = paths
        self.zipfio_data = zipfio_data
    def is_zipped(self):
        return bool(self.zipfio_data)
    def read_file(self, path, require_zipped=True):
        if self.is_zipped():
            if path in self.zipfio_data:
                return self.zipfio_data[path]
            else:
                raise FileNotFoundError('Not in zipped files:', str(path))
        if require_zipped and path not in self.paths:
            raise RuntimeError('Tried to read file that will not be zipped: "' + path + '"')
        with open(path, 'r') as file_in:
            text = file_in.read()
        return text
    def write_file(self, path, text):
        if self.is_zipped():
            raise RuntimeError('Tried to write to already zipped data')
        with open(path, 'w') as file_out:
            file_out.write(text)
    def zip_files(self, zipped_data_path):
        if self.is_zipped():
            raise RuntimeError('Tried to zip when already zipped')
        zipped_files = {}
        for path in self.paths:
            with open(path, 'r') as file_in:
                zipped_files[path] = file_in.read()
        zd_text = 'zipfio_data = ' + json.dumps(zipped_files)
        with open(zipped_data_path, 'w') as file_out:
            file_out.write(zd_text)