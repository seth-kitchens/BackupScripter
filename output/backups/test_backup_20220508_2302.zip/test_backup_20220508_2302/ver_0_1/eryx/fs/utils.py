import os
import re
import time
from datetime import datetime

def get_date_postfix(date_string='_YYYYMMDD_HHmmss'):
    return process_date_string(date_string)

def process_date_string(date_string, do_lstrip=True, dt=None):
    now = dt if dt else datetime.now()
    def lstrip_time(a):
        code = now.strftime(a)
        if do_lstrip:
            code = code.lstrip('0')
            code = code if len(code) else '0'
        return code

    codes = {}
    codes['YYYY'] = now.strftime('%Y')
    codes['MM'] = lstrip_time('%m')
    codes['DD'] = lstrip_time('%d')
    codes['HH'] = now.strftime('%H')
    codes['hh'] = lstrip_time('%I')
    codes['mm'] = now.strftime('%M')
    codes['ss'] = now.strftime('%S')
    codes['UU'] = str(int(time.time()))
    for key, value in codes.items():
        date_string = date_string.replace(key, value)
    return date_string

def find_nonexistent_dir(path):
    if os.path.exists(path):
        return ''
    ne = path
    parent = ne
    while not os.path.exists(parent):
        ne = parent
        parent = parent_dir(parent)
    return ne

def is_within_age_seconds(path, lower=-1, upper=-1):
    ctime = os.path.getctime(path)
    age = time.time() - ctime
    if lower >= 0 and age < lower:
        return False
    if upper >= 0 and age > upper:
        return False
    return True

def is_within_age_days(path, lower=-1, upper=-1):
    seconds_in_day = 60 * 60 * 24
    return is_within_age_seconds(path, lower * seconds_in_day, upper * seconds_in_day)

def parent_dir(path, repeat_times=0):
    parent_path = os.path.abspath(os.path.join(path, os.pardir))
    if repeat_times:
        return parent_dir(parent_path, repeat_times-1)
    return parent_path

def create_file_safely(path, lines, end=''):
    if os.path.exists(path):
        print('ERROR: File already exists: ' + path)
        return False
    if not os.path.exists(parent_dir(path)):
        print('ERROR: Destination must exist: ' + parent_dir(path))
        return False
    file = open(path, 'w')
    for line in lines:
        file.write(line + end)
    file.close()
    return

# returns indices of start and end of first match found
def find_mre(lines:list[str], mre):
    """
    ---
    Find multi-line regex in lines
    
    ---
    Args:
        lines: list of lines 
        mre: list of regex's
    ---
    Returns:
        tuple[int, int]: indices of start and end of first match found, respectively
    """
    if not mre:
        return -1, -1
    for i_line in range(len(lines)):
        for i_re in range(len(mre) + 1):
            if i_re >= len(mre):
                # match found
                return i_line, i_line + i_re - 1
            if i_line + i_re > len(lines):
                break
            if not re.search(mre[i_re], lines[i_line + i_re]):
                break
    return -1, -1

def copy_file_section(path, section_title_from, section_title_to, do_include_from=True):
        mre_from = [
            '^#+$',
            '^## ' + section_title_from + ' #*$',
            '^#+$'
        ]
        mre_to = [
            '^#+$',
            '^## ' + section_title_to + ' #*$',
            '^#+$'
        ]
        lines = copy_file_lines_regex(path, mre_from, mre_to, do_include_from=do_include_from, do_include_to=False)
        if not lines:
            return ''
        return ''.join(lines)

# mre = multiline regex
def copy_file_lines_regex(path, mre_from, mre_to=None, do_include_from=True, do_include_to=False):
    lines = file_to_lines(path)

    if not mre_from:
        return []

    # Remove code
    from_match_start, from_match_end = find_mre(lines, mre_from)
    if from_match_start < 0 or from_match_end < 0:
        print('ERROR: mre_from not matched')
        return []
    from_index = from_match_start if do_include_from else from_match_end + 1

    if mre_to:
        to_match_start, to_match_end = find_mre(lines, mre_to)
        if to_match_start < 0 or to_match_end < 0:
            print('ERROR: mre_to not matched')
            return []
        to_index = to_match_end + 1 if do_include_to else to_match_start
    else:
        to_index = len(lines)

    return lines[from_index:to_index]

def is_path_in_path(subpath: str, path: str):
    subpath = os.path.normpath(subpath)
    return subpath.startswith(os.path.abspath(path)+os.sep)

def normjoin(current_dir, path):
    abs_path = os.path.normpath(os.path.join(current_dir, path))
    return abs_path

def file_to_string(path):
    file = open(path, 'r')
    text = file.read()
    file.close()
    return text

def file_to_lines(path):
    file = open(path, 'r')
    lines = []
    for line in file:
        lines.append(line)
    return lines