import os
import pprint
from numbers import Number

from eryx.fs import utils as fs_utils
from eryx.text import utils as up


class ScriptBuilder:
    def __init__(self):
        self.lines:list[str] = []
        self.imports:str = []
        self.indent = 0
        self.indent_spaces = 0
        pass

    def pull_file(self, path):
        pass

    def add_line(self, line=''):
        self.lines.append(str(line).strip('\n'))

    def add_lines(self, lines):
        for line in lines:
            self.add_line(line)

    def add_str(self, s):
        self.add_lines(s.strip().split('\n'))
    
    def add_line_comment(self, text):
        self.add_line(''.rjust(self.indent * self.indent_spaces) + '# ' + text)

    def add_line_assignment(self, name, data_string, comment):
        line = name + ' = ' + data_string
        if comment:
            line += ' # ' + comment
        self.add_line(line)
    
    def add_var_rstr_list(self, name, data):
        lines = []
        lines.append(name)
        lines[0] += ' = ['
        if not data:
            lines[0] += ']'
            self.add_lines(lines)
            return
        for i in range(len(data)):
            line = '    R"' + str(data[i]) + '"'
            if i + 1 < len(data):
                line += ','
            lines.append(line)
        lines.append(']')
        self.add_lines(lines)
    
    def add_var_pprint(self, name, data, comment:str=''):
        lines = pprint.pformat(data, indent=2, sort_dicts=False).split('\n')
        lines[0] = name + ' = ' + lines[0]
        self.add_lines(lines)
    
    def add_var_str(self, name, data, comment:str=''):
        self.add_line_assignment(name, '"' + data + '"', comment)
    
    def add_var_rstr(self, name, data, comment:str=''):
        self.add_line_assignment(name, 'R"' + data + '"', comment)

    def add_var_path(self, name, data, comment:str=''):
        self.add_var_rstr(name, os.path.normpath(str(data)), comment)
    
    def add_var(self, name, data, comment:str=''):
        if isinstance(data, str):
            self.add_var_str(name, data, comment)
        elif isinstance(data, list):
            self.add_var_pprint(name, data, comment)
        elif isinstance(data, dict):
            self.add_var_pprint(name, data, comment)
        elif isinstance(data, Number):
            self.add_line_assignment(name, str(data), comment)
        else:
            self.add_line_assignment(name, str(data), comment)

    def set_indent(self, new_indent, new_indent_spaces=-1):
        self.indent = new_indent
        if new_indent_spaces >= 0:
            self.indent_spaces = new_indent_spaces
    
    def add_section_banner(self, title):
        self.add_str(up.print_section_banner(title, length=120))
    
    def copy_file_section(path, section_title_from, section_title_to, do_include_from=True):
        mre_from = [
            '^#+$',
            '^## ' + section_title_from + ' #*$',
            '^#+$'
        ]
        mre_to = [
            '^#+$',
            '^## ' + section_title_to + ' #*$',
            '^#+$'
        ]
        lines = fs_utils.copy_file_lines_regex(path, mre_from, mre_to, do_include_from=do_include_from, do_include_to=False)
        return lines
