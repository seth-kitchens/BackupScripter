import json
import os
import sys
from pprint import pprint

from eryx.fs import utils as fs_utils
from eryx import g

class ScriptVariable:
    def __init__(self, name, value, info=None, info_button=None, to_string_func=None, from_string_func=None, do_save=True) -> None:
        self.name = name
        self.value = value
        self.info = info
        self.info_button = info_button if info_button != None or not info else bool(len(info) < 50)
        self.to_string_func = to_string_func
        self.from_string_func = from_string_func
        self.do_save = do_save
    def get(self):
        return self.value
    def set(self, value):
        self.value = value
    def to_string(self):
        if self.to_string_func:
            return self.to_string_func(self.value)
        return json.dumps(self.value)
    def from_string(self, s):
        if self.from_string_func:
            self.value = self.from_string_func(s)
        else:
            self.value = json.loads(s)

class ScriptDataGroup:
    def __init__(self, name, svs):
        self.name = name
        self.svs = svs

class ScriptMetadataGroup:
    def __init__(self, name, svs):
        self.name = name
        self.svs = svs
        for sv in self.svs:
            sv.do_save = False

class ScriptDataManager:
    GETDATA = '--getdata'
    def __init__(self, script_data_file, zipfio):
        self.groups = []
        self.svs = {}
        self.script_data_file = script_data_file
        self.zipfio = zipfio
        self.read_only = False
    def __getitem__(self, name):
        return self.svs[name].get()
    def __setitem__(self, name, value):
        if self.read_only:
            raise RuntimeError('ScriptDataManager is in read only mode')
        self.svs[name].set(value)
    def set_read_only(self, value=True):
        self.read_only = value
    def define_variables(self, groups):
        for group in groups:
            self.groups.append(group)
            for sv in group.svs:
                self.svs[sv.name] = sv
    def to_dict(self):
        d = {}
        for name, sv in self.svs.items():
            d[name] = sv.get()
        return d
    def from_dict(self, d):
        for name, sv in self.svs.items():
            if name in d:
                sv.set(d[name])
    def save_to_file(self, path=None, force_save=False):
        path = path if path else self.script_data_file
        if not path:
            raise Exception('Save file has not been specified')
        data = {}
        for name, sv in self.svs.items():
            if sv.do_save or force_save:
                data[name] = sv.to_string()
        if path == self.script_data_file:
            self.zipfio.write_file(path, json.dumps(data, indent=4))
        else:
            pass
    def load_save_file(self, path=None, require_zipped=True):
        path = path if path else self.script_data_file
        if not os.path.isfile(path):
            return
        data = json.loads(self.zipfio.read_file(path, require_zipped=require_zipped))
        for name, sv in self.svs.items():
            if name in data:
                sv.from_string(data[name])
    def verify_file_is_script(path):
        if not path.endswith('.pyz'):
            return False
        # TODO make this actually pull info from the .pyz file, perhaps search for a string inserted when zipping?
        return True
    def load_pyz(self, path):
        if not self.__class__.verify_file_is_script(path):
            raise ValueError('File is not a .pyz script')
        stripped_name = path[:-4]
        comm_file = stripped_name + fs_utils.get_date_postfix() + '.temp'
        command = 'python "' + path + '" ' + self.GETDATA + ' ' + comm_file
        os.system(command)
        self.load_save_file(comm_file, require_zipped=False)
        os.remove(comm_file)
    def get_data(self):
        i_flag = sys.argv.index(self.GETDATA)
        comm_file = sys.argv[i_flag+1]
        if os.path.exists(comm_file):
            raise FileExistsError(comm_file)
        parent_dir = fs_utils.parent_dir(comm_file)
        if not os.path.isdir(parent_dir):
            raise Exception('Bad parent folder', parent_dir)
        self.save_to_file(comm_file, do_overwrite=False)
    def print(self):
        pprint(self.to_dict())

class ScriptEditor:
    def __init__(self):
        pass