from abc import ABC, abstractmethod, ABCMeta
from pprint import pprint
from typing import Any
from eryx import g
import time
from functools import wraps

import PySimpleGUI as sg
from eryx.gui.event_manager import EventManager

__all__ = [
    'check_if_instances',
    'check_if_subclasses',
    'GuiElement',
    'iLayout',
    'iToggle',
    'iLength',
    'iPopupEdit',
    'iStringable',
    'initafter'
]

# OOP

def check_if_instances(obj, types):
    for t in types:
        if not isinstance(obj, t):
            raise TypeError('Obj ' + str(obj) + ' is not an instance of ' + str(t))
def check_if_subclasses(name, types):
    for t in types:
        if not issubclass(name, t):
            raise TypeError('Obj ' + str(name) + ' is not a subclass of ' + str(t))

"""
Partially Implemented
Implemented somewhat, but not (yet?) as interface/subclass/baseclass+gem/etc

self.disabled
    in GuiElement:
        __init__(): self.disabled = False
        save(): not called if self.disabled, instead None is saved to data[self.object_id]
        pull(): not called if self.disabled

    load(): ensure loading None sets appropriate value
    push(): update relevant disabled values. if desired, set displayed values to blank when disabled

iValid
    in GuiElement:
        __init__(): has_validity = False
    __init__(): validity defining parameters, e.g. negative_invalid
    push_validity(): change window values/colors/etc based on if self is valid
    is_valid(): return whether object is valid with current values. call before or after modifying object's values
    reset_value(): set the objects values to some default, call when trying to set object's values to invalid
    get_layout()/etc: enable_events so validity colors are updated
    handle_event(): add events where pull() then push_validity()
    save(): save as None if not valid
    load(): ensure loading None sets appropriate value
    push(): if desired, set displayed valued to blank when invalid

"""

class iLayout(ABC):
    @abstractmethod
    def get_layout(self):
        pass

# - Add (if not self.is_toggled() -> data[...] = get_off_value()) to save()
# - Add state information to __init__ (e.g. self.disabled)
# - Make sure push and pull methods respect on/off state
class iToggle(ABC):
    @abstractmethod
    def toggle(self, value):
        pass
    @abstractmethod
    def is_toggled(self):
        pass
    @abstractmethod
    def refresh_toggle(self):
        pass

class iLength(ABC):
    @abstractmethod
    def __len__(self):
        pass

class iPopupEdit(ABC):
    @abstractmethod
    def popup_edit(edit_data):
        pass

class iStringable(ABC):
    @abstractmethod
    def to_string(self):
        pass
    @abstractmethod
    def load_data_from_string(self, s):
        pass

def initafter(f):
    @wraps(f)
    def func(*args, **kwargs):
        rv = f(*args, **kwargs)
        if not args[0].events_defined:
            args[0].define_events()
            args[0].events_defined = True
        return rv
    return func

# GuiElement

class GuiElement(ABC):
    def __init__(self, object_id) -> None:
        self.settings = {}
        g.settings.pull(self.settings, ['all', 'gui_element'])
        self.object_id = object_id
        self.keys = {}
        self.define_keys()
        self.ges = {}
        self.requestable_events = {}
        self.sg_kwargs = {}
        self.sg_kwargs_all_dict = {}
        self.sg_kwargs_functions = {}
        self.disabled = False
        self.has_validity = False
        self.prev_click_time = 0
        self.em = EventManager()
        self.events_defined = False
        
    
    ## Abstracts

    # Layout

    # These are virtual, but one must be implemented
    # postfix partials/alternatives (e.g. get_sge_basename(...), get_sge_extension(...))
    def _get_sge(self):
        return None
    @initafter
    def get_sge(self): # One sg element
        rv = self._get_sge()
        return rv
    
    def _get_row(self):
        return None
    @initafter
    def get_row(self): # A list of sg elements
        rv = self._get_row()
        return rv
    
    def _get_layout(self):
        return None
    @initafter
    def get_layout(self): # A list of lists of sg elements
        rv = self._get_layout()
        return rv

    # Data
    
    @abstractmethod
    def _init(self):
        pass
    def init(self):
        self._init()
    
    @abstractmethod
    def _save(self, data):
        pass
    def save(self, data):
        for ge in self.ges.values():
            ge.save(data)
        if self.disabled:
            data[self.object_id] = None
        elif not self.is_valid():
            data[self.object_id] = None
        else:
            self._save(data)
    
    @abstractmethod
    def _load(self, data):
        pass
    def load(self, data):
        for ge in self.ges.values():
            ge.load(data)
        if self.object_id in data.keys():
            self._load(data)
    
    @abstractmethod
    def _pull(self, values):
        pass
    def pull(self, values):
        if self.disabled:
            return
        self._pull(values)
    
    @abstractmethod
    def _push(self, window):
        pass
    def push(self, window):
        self._push(window)
    
    @abstractmethod
    def _init_window(self, window):
        pass
    def init_window(self, window):
        self.push(window)
        self._init_window(window)

    # Keys and Events

    @abstractmethod
    def define_keys(self):
        pass

    @abstractmethod
    def define_events(self):
        pass

    ## Virtuals

    def handle_event(self, window, event, values, data):
        self.em.handle_event(window, event, values, data)
        for ge in self.ges.values():
            ge.handle_event(window, event, values, data)

    def get_key(self, *key_prefixes):
        if len(key_prefixes) == 1:
            return self.keys[key_prefixes[0]]
        else:
            return self.ges[key_prefixes[0]].get_key(*key_prefixes[1:])

    def _is_valid(self):
        pass
    def is_valid(self):
        if not self.has_validity:
            return True
        return self._is_valid()
    
    def _push_validity(self, window):
        pass
    def push_validity(self, window):
        if not self.has_validity:
            return
        self._push_validity(window)
    
    ## Other

    def prepare_event_manager(self):
        em = EventManager()
        em.handle_event_function(self.handle_event)
        return em

    def set_sg_kwargs(self, key_prefix, overwrite_kwargs=True, **kwargs):
        if not key_prefix in self.sg_kwargs:
            self.sg_kwargs[key_prefix] = {}
            self.sg_kwargs[key_prefix].update(self.sg_kwargs_all_dict)
        sg_kwargs = self.sg_kwargs[key_prefix]
        for k, v in kwargs.items():
            if overwrite_kwargs or not k in sg_kwargs:
                sg_kwargs[k] = v
        return self
    
    # Calling during init ensures dict in kwargs is set before get_layout() is called,
    #     as well as not overwriting values set at time of object instantiation
    def init_sg_kwargs(self, key_prefix, **kwargs):
        self.set_sg_kwargs(key_prefix, overwrite_kwargs=False, **kwargs)
        return self
    
    def sg_kwargs_all(self, **kwargs):
        self.sg_kwargs_all_dict.update(kwargs)
        for key_prefix in self.sg_kwargs.keys():
            self.set_sg_kwargs(key_prefix, **kwargs)
        return self
    

    
    def init_data(self, value):
        """Like calling load(data) while data[object_id] == value"""
        self.load({self.object_id: value})
        return self
    
    def get_value(self, values, key): return values[self.keys[key]]
    


    @classmethod
    def key(key_prefix, key_root, key_postfix=''):
        return str(key_prefix) + str(key_root) + str(key_postfix)
        
    def get_keys(self): return list(self.keys.keys())
    def get_object_id(self): return self.object_id
    def add_key(self, key_prefix):
        self.keys[key_prefix] = key_prefix + self.get_object_id()
    def add_keys(self, key_prefixes):
        for kp in key_prefixes:
            self.add_key(kp)



    def sge(self, key_prefix, ge):
        self.add_ge(key_prefix, ge)
        return self.ges[key_prefix].get_sge()
    def row(self, key_prefix, ge):
        self.add_ge(key_prefix, ge)
        return self.ges[key_prefix].get_row()
    def layout(self, key_prefix, ge):
        self.add_ge(key_prefix, ge)
        return self.ges[key_prefix].get_layout()



    def add_ge(self, key_prefix, ge):
        if key_prefix not in self.ges:
            ge.init()
            self.ges[key_prefix] = ge

    
    
    def disable(self, window, value=True):
        self.disabled = value
        self.push(window)
    
    def request_event(self, window, request, values, data):
        if request in self.requestable_events.keys():
            self.handle_event(window, self.requestable_events[request], values, data)
    
    def add_rkey(self, key):
        self.add_key(key)
        self.requestable_events[key] = self.keys[key]
    
    def check_double_click(self):
        """Register a click, then return if it is a double click.\n
        Don't forget to set the sg kwarg bind_return_key if needed."""
        click_time = time.time()
        if (click_time - self.prev_click_time) < self.settings['double_click_secs']:
            is_double_click = True
        else:
            is_double_click = False
        self.prev_click_time = click_time
        return is_double_click
    register_click = check_double_click
    """Alias for check_double_click(), makes it more clear that ignoring the is_double_click rv is intentional"""

    def wrap_event_function(self, func, pull=False, push=False):
        def f(window, event, values, data):
            if pull:
                self.pull(values)
            func(window, event, values, data)
            if push:
                self.push(window)
        return f
    
    @classmethod
    def pull_push_event(event_function):
        def func(self, window, event, values, data):
            self.pull(values)
            rv = event_function(self, window, event, values, data)
            self.push(window)
            return rv
        return func
        


# This is for reference, as well as to copy/paste into a new GuiElement subclass
class GuiElementExample(GuiElement):
    def __init__(self, object_id, label, value) -> None:
        super().__init__(object_id)
        self.label = label
        self.value = value

    ### GuiElement

    # Layout

    def get_layout(self):
        layout = [[]]
        return layout
    def get_row(self):
        row = []
        if self.label:
            row.append(sg.Text(self.label, key=self.keys['Label'], **self.sg_kwargs['Label']))
        row.append(sg.Input(self.value, key=self.keys['ExampleIn'], **self.sg_kwargs['ExampleIn']))
        return row
    def get_sge(self):
        sge = None
        return sge
    
    # Data

    def _init(self):
        self.init_sg_kwargs('Label')
        self.init_sg_kwargs('ExampleIn')
    def _save(self, data):
        value = self.value
        data[self.object_id] = value
    def _load(self, data):
        super().load(data)
        value = data[self.object_id]
        if value == None:
            value = 'DEFAULT'
        self.value = value
    def _pull(self, values):
        pass
    def _push(self, window):
        sge_example_in = window[self.keys['ExampleIn']]
        sge_example_in.update(disabled=self.disabled)
        if self.disabled:
            sge_example_in.update('')
        else:
            sge_example_in.update(self.value)
    def _init_window(self, window):
        self.push(window)
    
    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('Label')
        self.add_key('ExampleIn')
    
    def define_events(self):
        super().define_events()

    # Others

    def sg_kwargs_label(self, **kwargs):
        self.set_sg_kwargs('Label', **kwargs)
        return self
    def sg_kwargs_example_in(self, **kwargs):
        self.set_sg_kwargs('ExampleIn', **kwargs)
        return self

    ### GuiElementExample

    def set_value(self, value):
        if value == None:
            self.reset()
            return False
        self.value = value
        return True
    def reset(self):
        self.set_value('DEFAULT')
    def update(self, window, value):
        self.set_value(value)
        self.push(window)
