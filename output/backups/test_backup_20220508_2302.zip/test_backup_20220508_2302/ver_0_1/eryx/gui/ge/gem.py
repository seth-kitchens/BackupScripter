import PySimpleGUI as sg
from eryx.gui.ge.ge import GuiElement
from eryx.gui.event_manager import EventManager

# GuiElement Manager

class GuiElementManager:
    num_gems = 0
    num_gem_keys = 0
    def __init__(self):
        self.gem_id = GuiElementManager.num_gems
        GuiElementManager.num_gems += 1
        self.ges = {}
        self.gem_keys = {}
    def __getitem__(self, key):
        return self.ges[key]
    def __setitem__(self, key, value):
        self.ges[key] = value
    def add_ge(self, ge, do_overwrite=False):
        id = ge.object_id
        if do_overwrite or not id in self.ges.keys():
            ge.init()
            self.ges[id] = ge
    
    # add an object if it doesn't already exist and return its layout elements

    def layout(self, ge):
        self.add_ge(ge)
        return self.ges[ge.object_id].get_layout()
    def row(self, ge):
        self.add_ge(ge)
        return self.ges[ge.object_id].get_row()
    def sge(self, ge):
        self.add_ge(ge)
        return self.ges[ge.object_id].get_sge()
    
    def pull_save_all(self, values, data):
        self.pull_all(values)
        self.save_all(data)
    def save_all(self, data):
        for ge in self.ges.values():
            ge.save(data)
    def load_all(self, data):
        for ge in self.ges.values():
            ge.load(data)
    def init_window_all(self, window):
        for ge in self.ges.values():
            #if ge.object_id in window.AllKeysDict:
            ge.init_window(window)
    def pull_all(self, values):
        for ge in self.ges.values():
            ge.pull(values)
    def push_all(self, window):
        for ge in self.ges.values():
            ge.push(window)
    def handle_event(self, window, event, values, data):
        for ge in self.ges.values():
            ge.handle_event(window, event, values, data)
    def prepare_event_manager(self, data, em=None):
        em = em if em != None else EventManager()
        em.handle_event_function(self.handle_event)
        em.init_window_function(self.init_window_all)
        em.save_function(self.save_all, data)
        em.load_function(self.load_all, data)
        em.pull_function(self.pull_all)
        em.push_function(self.push_all)
        return em  

    def get_key(self, *key_prefixes):
        if len(key_prefixes) <= 1:
            raise RuntimeError
        else:
            return self.ges[key_prefixes[0]].get_key(*key_prefixes[1:])
    
    # generate a unique key that won't need to be used manually
    def gem_key(self, unique_string):
        if unique_string in self.gem_keys:
            return self.gem_keys[unique_string]
        us_clip = unique_string[:30].replace(' ', '').replace('\n', '') # for debug if needed, is unique event without this
        key = 'GEM_KEY_' + str(self.gem_id) + '_' + str(GuiElementManager.num_gem_keys) + '_' + us_clip
        GuiElementManager.num_gem_keys += 1
        self.gem_keys[unique_string] = key
        return key
