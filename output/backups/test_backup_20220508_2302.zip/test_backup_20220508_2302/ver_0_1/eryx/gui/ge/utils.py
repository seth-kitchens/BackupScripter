import PySimpleGUI as sg

from eryx.gui.elements import InfoButton
from eryx.gui.sg import utils as sg_utils

button_size = sg_utils.button_size

def info(gem, info_text, button_text=None, header='', subheader='', bt=None, sg_kwargs=None):
    if button_text == None:
        if bt:
            button_text = bt
        else:
            button_text = '?'
    
    key = gem.gem_key(info_text)
    ge = InfoButton(object_id=key, text=button_text, info_text=info_text, header=header, subheader=subheader)
    if not sg_kwargs:
        sg_kwargs = {}
    if not 'size' in sg_kwargs:
        sg_kwargs['size'] = button_size.XS
    ge.sg_kwargs_info(**sg_kwargs)
    return gem.sge(ge)
