from abc import ABC, abstractmethod

import PySimpleGUI as sg
from eryx import g
from eryx.gui.event_manager import EventManager
from eryx.gui.sg import utils as sg_utils
from eryx.gui.ge.gem import GuiElementManager


class Window(ABC):
    def __init__(self, title, data=None) -> None:
        self.title = title
        self.data = data.copy() if data != None else {}
        self.gem = GuiElementManager()

        # Before layout definition
        self.menu_bar = sg_utils.MenuBar()
        self.define_menu_bar()

        # Layout definition
        self.get_layout() # trash a layout to create the GuiElements defined in it

        # After layout definition
        self.em = EventManager()
        self.define_events()
    
    # Layout

    def define_menu_bar(self):
        pass
    @abstractmethod
    def get_layout(self):
        pass

    # Events

    @abstractmethod
    def define_events(self):
        self.em.handle_event_function(self.gem.handle_event)

    # Data

    def save(self, data):
        self.gem.save_all(data)

    def load(self, data):
        self.gem.load_all(data)

    def pull(self, values):
        self.gem.pull_all(values)

    def push(self, window):
        self.gem.push_all(window)

    def init_window(self, window):
        self.gem.init_window_all(window)

    # Other

    def open(self):
        layout = self.get_layout()
        window = sg.Window(self.title, layout, finalize=True)
        self.load(self.data)
        self.init_window(window)
        rv = self.em.event_loop(window)
        if rv:
            self.pull(self.em.values)
            self.save(self.data)
        return rv
    
    def get_data(self):
        return self.data

class NonBlockingWindow(ABC):
    def __init__(self, window_id, title) -> None:
        self.window_id = window_id
        self.title = title
        self.keys = {}
        self.window = None
    def add_key(self, key_prefix):
        self.keys[key_prefix] = key_prefix + self.window_id
    def open(self):
        if self.window:
            return
        layout = self.get_layout()
        self.window = sg.Window(self.title, layout, finalize=True)
    def close(self):
        if not self.window:
            return
        self.window.close()
        self.window = None
    def update(self):
        event, values = self.window.read(10)
    @abstractmethod
    def get_layout(self):
        pass
NBWindow = NonBlockingWindow

class ProgressWindow(NBWindow):
    def __init__(self, window_id, title='Progress', header='Progress', no_meter=False, no_text=False) -> None:
        super().__init__(window_id, title)
        self.header = header
        self.is_progress_visible = (not no_meter)
        self.is_out_visible = (not no_text)
        self.add_key('Out')
        self.add_key('Progress')
    
    ### NBWindow

    def get_layout(self):
        layout = [
            [sg.Text(self.header, text_color=g.colors.header)]
        ]
        layout.append([sg.Multiline('', key=self.keys['Out'], size=(50, 5), expand_x=True, autoscroll=True, no_scrollbar=True, visible=self.is_out_visible)])
        layout.append([sg.Progress(1000, orientation='h', size=(1, 15), expand_x=True, key=self.keys['Progress'])])
        return layout

    ### ProgressWindow

    def __getitem__(self, key_prefix):
        return self.keys[key_prefix]
    def update_progress(self, progress:float):
        self.window[self.keys['Progress']].UpdateBar(progress * 1000)
    def set_text(self, text):
        self.window[self.keys['Out']](text)
    def append_text(self, text):
        self.window[self.keys['Out']].print(text)
    def progress_function(self, append_text=None, progress=None):
        if append_text:
            self.append_text(append_text)
        if progress:
            self.update_progress(progress)
        self.update()
    def get_progress_function(self):
        def func(append_text=None, progress=None):
            self.progress_function(append_text, progress)
        return func
