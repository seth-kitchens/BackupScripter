import PySimpleGUI as sg

from eryx.gui.ge.ge import *
from eryx.gui.popup import PopupBuilder

__all__ = ['Header', 'InfoButton']

class Header(GuiElement):
    def __init__(self, object_id, text) -> None:
        super().__init__(object_id)
        self.text = text

    ### GuiElement

    # Layout
    
    def _get_sge(self):
        return sg.Text(self.text, key=self.keys['Text'], **self.sg_kwargs['Text'])
    
    # Data

    def _init(self):
        self.init_sg_kwargs('Text', text_color='gold')
    def _save(self, data):
        pass
    def _load(self, data):
        pass
    def _pull(self, values):
        pass
    def _push(self, window):
        pass
    def _init_window(self, window):
        pass

    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('Text')
    
    def define_events(self):
        super().define_events()

    # Other

    def sg_kwargs_text(self, **kwargs):
        return self.set_sg_kwargs('Text', **kwargs)

class InfoButton(GuiElement):
    def __init__(self, object_id, text='Info', info_text=None, title='Info', header=None, subheader=None) -> None:
        super().__init__(object_id)
        self.text = text
        self.info_text = info_text
        self.title = title
        self.header = header
        self.subheader = subheader
    
    ### GuiElement

    # Layout

    def _get_sge(self):
        if len(self.text) < 2:
            self.sg_kwargs_info(size=(2, 1))
        return sg.Button(self.text, key=self.keys['Info'], **self.sg_kwargs['Info'])

    # Data

    def _init(self):
        self.init_sg_kwargs('Info')
    def _save(self, data):
        pass
    def _load(self, data):
        pass
    def _pull(self, values):
        pass
    def _push(self, window):
        pass
    def _init_window(self, window):
        pass
    
    # Keys and Events

    def define_keys(self):
        super().define_keys()
        self.add_keys(['Info'])
    
    def define_events(self):
        super().define_events()
        def event_info(window, event, values, data):
            self.info_popup()
        self.em.event_function(self.keys['Info'], event_info)

    # Other

    def sg_kwargs_info(self, **kwargs):
        self.set_sg_kwargs('Info', **kwargs)

    ### InfoButton

    def info_popup(self):
        PopupBuilder().textwrap(self.info_text).title(self.title).header(self.header).subheader(self.subheader).ok().open()
