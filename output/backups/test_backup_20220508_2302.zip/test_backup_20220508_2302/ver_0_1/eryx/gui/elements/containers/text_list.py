import copy
import json
from typing import Any

import PySimpleGUI as sg
from eryx.gui.event_manager import EventManager
from eryx.gui.ge.ge import *
from eryx.gui.popup import Popups

__all__ = ['TextList']

class TextList(GuiElement, iLength, iPopupEdit, iStringable):
    def __init__(self, object_id, delim=None, lborder='"', rborder='"', strip='', lstrip='', rstrip='', empty_text=''):
        super().__init__(object_id)
        self.delim = delim
        self.lborder = lborder
        self.rborder = rborder
        strip = strip if strip != None else ''
        self.lstrip = strip
        self.rstrip = strip
        self.lstrip += lstrip
        self.rstrip += rstrip
        self.items = []
        self.selected_index = None
        self.empty_text = empty_text if empty_text else ''
    
    ### GuiElement

    # Layout
    
    def _get_layout(self):
        move_button_size = (2, 1)
        column_move_buttons = sg.Column([
            [sg.Button('⇑', key=self.keys['MoveToTop'], size=move_button_size)],
            [sg.Button('↑', key=self.keys['MoveUp'], size=move_button_size)],
            [sg.Button('↓', key=self.keys['MoveDown'], size=move_button_size)],
            [sg.Button('⇓', key=self.keys['MoveToBottom'], size=move_button_size)]
        ])
        main_button_kwargs = {
            'size': (8, 1)
        }
        row_buttons_main_top = [
            sg.Button('Add', key=self.keys['Add'], **main_button_kwargs),
            sg.Button('Edit', key=self.keys['Edit'], **main_button_kwargs),
            sg.Button('Clone', key=self.keys['Clone'], **main_button_kwargs)
        ]
        row_buttons_main_bottom = [
            sg.Button('Remove', key=self.keys['Remove'], expand_x=True, **main_button_kwargs),
            sg.Button('Remove All', key=self.keys['RemoveAll'], expand_x=True, **main_button_kwargs)
        ]
        column_buttons_main = sg.Column(justification='center', layout=[
            row_buttons_main_top,
            row_buttons_main_bottom
        ])
        layout = [
            [column_move_buttons, self.get_sge_listbox()],
            [column_buttons_main]
        ]
        return layout
    
    def get_sge_listbox(self, keys=None):
        keys = keys if keys else self.keys
        listbox_height = len(self.items)
        if listbox_height < 3: listbox_height = 5
        elif listbox_height > 10: listbox_height = 10
        return sg.Listbox(self.items, key=keys['Listbox'], size=(30, listbox_height), expand_x=True, expand_y=True, enable_events=True, bind_return_key=True)    
    
    # Data

    def _init(self):
        pass
    def _save(self, data):
        data[self.object_id] = self.items.copy()
    def _load(self, data):
        self.items.clear()
        self.items.extend(data[self.object_id])
    def _pull(self, values):
        pass
    def _push(self, window):
        sge_listbox = window[self.keys['Listbox']]
        sge_listbox.update(self.get_display_list())
        if self.selected_index != None:
            sge_listbox.set_value([self.get_selection()])
        else:
            sge_listbox.update(set_to_index=[])
    def _init_window(self, window):
        window[self.keys['Listbox']].Widget.config(activestyle='none')
        self.push(window)
    
    # Keys and Events

    def define_keys(self):
        super().define_keys()
        self.add_key('Listbox')
        self.add_key('Add')
        self.add_key('Edit')
        self.add_key('Remove')
        self.add_key('RemoveAll')
        self.add_key('Clone')
        self.add_key('MoveUp')
        self.add_key('MoveDown')
        self.add_key('MoveToTop')
        self.add_key('MoveToBottom')

    def define_events(self):
        super().define_events()
        def event_add(window, event, values, data):
            item = Popups.edit_string('', title='Add')
            item = self.format_item(item)
            if not item:
                return
            if item in self.items:
                if not Popups.confirm('Entry "' + item + '" already exists. Move to bottom of list?'):
                    return
                self.items.remove(item)
            self.items.append(item)
            self.select_item(item)
            self.push(window)
        self.em.event_function(self.keys['Add'], event_add)
    
        def event_edit(window, event, values, data):
            if self.selected_index == None:
                return
            item = self.get_selection()
            new_item = Popups.edit_string(item, title='Edit', texts=['Old: "' + item + '"'])
            new_item = self.format_item(new_item)
            if new_item == '':
                self.items.remove(item)
                self.selected_index = None
            elif (not new_item) or new_item == item:
                return
            else:
                self.items[self.selected_index] = new_item
                self.select_item(new_item)
            self.push(window)
        self.em.event_function(self.keys['Edit'], event_edit)
        
        def event_remove(window, event, values, data):
            if self.selected_index == None:
                return
            self.items.pop(self.selected_index)
            self.deselect()
            self.push(window)
        self.em.event_function(self.keys['Remove'], event_remove)
        
        def event_remove_all(window, event, values, data):
            if not len(self):
                return
            if not Popups.warning('Remove all entries?'):
                return
            self.items.clear()
            self.deselect()
            self.push(window)
        self.em.event_function(self.keys['RemoveAll'], event_remove_all)
        
        def event_clone(window, event, values, data):
            if self.selected_index == None:
                return
            item = self.get_selection()
            i = 1
            while (item + str(i)) in self.items:
                i += 1
            new_item = item + str(i)
            index = self.items.index(item)
            self.items.insert(index+1, new_item)
            self.select_item(new_item)
            self.push(window)
        self.em.event_function(self.keys['Clone'], event_clone)
        
        def event_move_up(window, event, values, data):
            if self.selected_index == None:
                return
            index = self.selected_index
            if index == 0:
                return
            temp = self.items[index-1]
            self.items[index-1] = self.items[index]
            self.items[index] = temp
            self.selected_index -= 1
            self.push(window)
        self.em.event_function(self.keys['MoveUp'], event_move_up)
        
        def event_move_down(window, event, values, data):
            if self.selected_index == None:
                return
            index = self.selected_index
            if index + 1 >= len(self.items):
                return
            temp = self.items[index+1]
            self.items[index+1] = self.items[index]
            self.items[index] = temp
            self.selected_index += 1
            self.push(window)
        self.em.event_function(self.keys['MoveDown'], event_move_down)
        
        def event_move_to_top(window, event, values, data):
            if self.selected_index == None:
                return
            item = self.get_selection()
            self.items.pop(self.selected_index)
            self.items.insert(0, item)
            self.selected_index = 0
            self.push(window)
        self.em.event_function(self.keys['MoveToTop'], event_move_to_top)
        
        def event_move_to_bottom(window, event, values, data):
            if self.selected_index == None:
                return
            item = self.get_selection()
            self.items.pop(self.selected_index)
            self.items.append(item)
            self.selected_index = len(self.items) - 1
            self.push(window)
        self.em.event_function(self.keys['MoveToBottom'], event_move_to_bottom)
        
        def event_listbox(window, event, values, data):
            is_double_click = self.check_double_click()
            if not self.items:
                self.deselect()
                self.push(window)
                return
            if is_double_click:
                return self.handle_event(window, self.keys['Edit'], values, data)
            selections = window[self.keys['Listbox']].get_indexes()
            if len(selections):
                self.selected_index = selections[0]
        self.em.event_function(self.keys['Listbox'], event_listbox)

    # Other

    ### TextList

    # iLength

    def __len__(self):
        return len(self.items)

    # Containable

    def popup_edit(self):
        layout = [self.get_layout()]
        layout.extend([
            [sg.HSeparator()],
            [sg.Ok()]
        ])
        em = self.prepare_event_manager()
        em.true_event('Ok')
        em.false_event(sg.WIN_CLOSED)
        return em.event_loop(sg.Window('Edit', layout, finalize=True))

    # iStringable

    def to_string(self):
        self.format_items()
        if self.delim:
            s_join = self.delim
            if ' ' in self.lstrip:
                s_join += ' '
            return s_join.join(self.items.copy())
        else:
            return json.dumps(self.items)
    def load_data_from_string(self, s):
        self.items.clear()
        if self.delim:
            items = s.split(self.delim)
        else:
            items = json.loads(s)
        for item in items:
            item = self.format_item(item)
            if item:
                self.items.append(item)

    # Other

    def add_item(self, item):
        self.items.append(item)
    def get_selection(self):
        return self.items[self.selected_index]
    def select_item(self, item):
        self.selected_index = self.items.index(item)
    def deselect(self):
        self.selected_index = None
    def format_item(self, item):
        return item.lstrip(self.lstrip).rstrip(self.rstrip)
    def format_items(self):
        items = self.items.copy()
        self.items.clear()
        for item in items:
            item = self.format_item(item)
            if item:
                self.items.append(item)
    def item_to_display_item(self, item):
        return self.lborder + item + self.rborder
    def display_item_to_item(self, display_item):
        return display_item[len(self.lborder):0 - len(self.rborder)]
    def get_display_list(self):
        display_list = []
        for item in self.items:
            display_list.append(self.item_to_display_item(item))
        if not display_list:
            display_list.append(self.empty_text)
        return display_list

    

