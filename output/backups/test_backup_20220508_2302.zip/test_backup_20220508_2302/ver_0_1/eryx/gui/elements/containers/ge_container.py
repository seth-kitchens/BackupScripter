import PySimpleGUI as sg

from eryx.gui.ge.ge import *

__all__ = ['CheckboxContainer']

class CheckboxContainer(GuiElement):
    def __init__(self, ge) -> None:
        check_if_instances(ge, [GuiElement, iToggle, iLayout])
        self.ge = ge
        self.contained_object_id = ge.get_object_id()
        object_id = 'CheckboxContainer(' + self.contained_object_id + ')'
        super().__init__(object_id)
        self.add_ge('Contained', ge)
    
    ### GuiElement

    # Layout
    
    def _get_row(self):
        value = self.ge.is_toggled()
        row = [
            sg.Checkbox(None, key=self.keys['Checkbox'], enable_events=True, default=value, pad=((5, 0), (0, 0))),
            sg.Column(layout=self.ge.get_layout())
        ]
        return row
    
    # Data
    
    def _init(self):
        self.ge.init()
        self.ge.refresh_toggle()
    def _save(self, data):
        pass
    def _load(self, data):
        self.ge.refresh_toggle()
    def _pull(self, values):
        self.ge.pull(values)
        self.ge.refresh_toggle()
    def _push(self, window):
        self.ge.push(window)
    def _init_window(self, window):
        self.ge.init_window(window)
    
    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('Checkbox')
        self.add_key('Contained')
    
    def define_events(self):
        super().define_events()
        def event_checkbox(window, event, values, data):
            value = values[self.keys['Checkbox']]
            self.ge.toggle(value)
        self.em.event_function(self.keys['Checkbox'], event_checkbox)

    # Other
    
    ### CheckboxContainer