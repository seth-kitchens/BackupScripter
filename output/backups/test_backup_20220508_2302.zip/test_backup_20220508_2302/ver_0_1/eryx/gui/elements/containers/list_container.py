from abc import ABC, abstractmethod

import PySimpleGUI as sg
from eryx import g
from eryx.gui.ge.ge import *

__all__ = ['ListContainer', 'CountContainer', 'StringContainer']

class ListContainer(GuiElement, ABC):
    def __init__(self, ge:GuiElement) -> None:
        check_if_instances(ge, [GuiElement, iLength])
        self.ge = ge
        self.contained_object_id = ge.get_object_id()
        object_id = 'ListContainer(' + self.contained_object_id + ')'
        super().__init__(object_id)
        self.add_ge('Contained', ge)
    
    ### GuiElement

    # Layout
    # Data

    def _init(self):
        pass
    def _save(self, data):
        pass
    def _load(self, data):
        pass
    @abstractmethod
    def _pull(self, values):
        pass
    @abstractmethod
    def _push(self, window):
        pass
    def _init_window(self, window):
        self.push(window)
    
    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('Edit')
    
    def define_events(self):
        super().define_events()
        def event_edit(window, event, values, data):
            self.ge.popup_edit()
        self.em.event_function(self.keys['Edit'], event_edit)
    
    # Other
    ###

# show the count of the contained list
class CountContainer(ListContainer):
    def __init__(self, text, ge:GuiElement) -> None:
        check_if_instances(ge, [GuiElement, iLength, iPopupEdit])
        super().__init__(ge)
        self.text = text
    
    ### GuiElement

    # Layout

    def _get_row(self):
        row = [
            sg.Text(self.text),
            sg.Text('0', key=self.keys['Count']),
            sg.Button('Edit', key=self.keys['Edit'])
        ]
        return row
    
    # Data

    def _pull(self, values):
        pass
    def _push(self, window):
        window[self.keys['Count']](str(len(self.ge)))
    
    # Keys and Events

    def define_keys(self):
        super().define_keys()
        self.add_key('Count')
    
    def define_events(self):
        super().define_events()

    # Other
    ###

# Show the contained list as a string
class StringContainer(ListContainer):
    def __init__(self, text, ge:GuiElement, folder_browse=False, blank_invalid=False, has_validity=False) -> None:
        check_if_instances(ge, [GuiElement, iLength, iPopupEdit, iStringable])
        super().__init__(ge)
        self.text = text
        self.folder_browse = folder_browse
        self.blank_invalid = blank_invalid
        if blank_invalid:
            self.has_validity = True
        else:
            self.has_validity = has_validity
    
    ### GuiElement

    # Layout

    def _get_row(self):
        if 'delim' in dir(self.ge):
            char_names = {
                ';': 'semicolon',
                ',': 'comma'
            }
            s_delim = self.ge.delim
            if s_delim in char_names:
                s_delim = char_names[s_delim]
            else:
                s_delim = '"' + s_delim + '"'
            tooltip = 'Items separated by ' + s_delim
        else:
            tooltip = None
        row = [
            sg.Text(self.text),
            sg.In(self.ge.to_string(), key=self.keys['In'], enable_events=True, tooltip=tooltip),
            sg.Button('Edit', key=self.keys['Edit'])
        ]
        # TODO this should really be a part of the textlist, not the container
        if self.folder_browse:
            row.insert(2, sg.In('', key=self.keys['Add'], visible=False, enable_events=True))
            row.insert(3, sg.FolderBrowse('Browse'))
        return row
    
    # Data

    def _pull(self, values):
        s = values[self.keys['In']]
        if s == None:
            return
        self.ge.load_data_from_string(s)
    def _push(self, window):
        self.push_validity(window)
        window[self.keys['In']](self.ge.to_string())
    
    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('In')
        self.add_key('Add')
    
    def define_events(self):
        super().define_events()
        def event_add(window, event, values, data):
            path = values[self.keys['Add']]
            if path:
                self.ge.add_item(path) # TODO not in interface
        self.em.event_function(self.keys['Add'], event_add)
        
        def event_in(window, event, values, data):
            self.pull(values)
            self.push_validity(window)
        self.em.event_function(self.keys['In'], event_in)

    # Other
    
    ### iValid
    
    def _push_validity(self, window):
        sg_in = window[self.keys['In']]
        if self.is_valid():
            sg_in.update(background_color = g.colors.valid)
        else:
            sg_in.update(background_color = g.colors.invalid)
    def _is_valid(self):
        if self.blank_invalid and not len(self.ge):
            return False
        return True
