import copy
from abc import ABC, abstractmethod

import PySimpleGUI as sg
from eryx.gui.event_manager import EventManager
from eryx.gui.ge.ge import *
from eryx.gui.popup import Popups
from eryx.gui.sg import utils as sg_utils
from eryx.data.ordered_dict import OrderedDict

__all__ = ['DetailList']

# TODO add double click -> edit

# An abstract class representing an edittable dict: item_dict:dict[item:str, data:Any]
# Abstract methods:
#     make_details(item:str, data:Any) -> str
#       - this is called on the current selection (item/data) to display details
#       - the returned str is sent to the sg.Multiline details window with the 
#     edit_data(item:str, data:Any) -> data:Any
#       - called when the Edit button or Add button is clicked
#       - data is overwritten by the returned value
#     data_to_string(data:Any) -> data:str
#       - called when saving to save item_dict as JSON: dict[str, str]
#     data_from_string(data:str) -> data:Any
#       - called when loading to load item_dict saved as JSON: dict[str, str]
class DetailList(GuiElement, iLength, iPopupEdit, ABC):
    def __init__(self, object_id, lstrip=' \n', rstrip=' \n'):
        super().__init__(object_id)
        self.lstrip = lstrip
        self.rstrip = rstrip
        self.item_dict = OrderedDict()
        self.selection = None
    
    ### GuiElement

    # Layout
    
    def _get_layout(self):
        move_button_size = (2, 1)
        column_move_buttons = sg.Column([
            [sg.Button('⇑', key=self.keys['MoveToTop'], size=move_button_size)],
            [sg.Button('↑', key=self.keys['MoveUp'], size=move_button_size)],
            [sg.Button('↓', key=self.keys['MoveDown'], size=move_button_size)],
            [sg.Button('⇓', key=self.keys['MoveToBottom'], size=move_button_size)]
        ])
        column_listbox = sg.Column(expand_y=True, layout=[
            [
                column_move_buttons,
                sg.Listbox(self.item_dict.keys(), key=self.keys['Listbox'], size=(30, 7), expand_y=True, enable_events=True)
            ]
        ])     
        row_buttons_main_top = self.get_row_buttons_main_top()
        row_buttons_main_bottom = self.get_row_buttons_main_bottom()
        column_buttons_main = sg.Column(layout=[
            row_buttons_main_top,
            row_buttons_main_bottom
        ])
        column_right = sg.Column(expand_x=True, layout=[
            [sg.Multiline('', key=self.keys['Details'], size=(85, 7), expand_x=True, disabled=True)],
            [
                column_buttons_main,
                sg.Push()
            ]
        ])
        layout = [[
            column_listbox,
            column_right
        ]]
        return layout

    def get_row_buttons_main_top(self):
        size = (8, 1)
        row = [
            sg.Button('Add', key=self.keys['Add'], size=size),
            sg.Button('Edit', key=self.keys['Edit'], size=size),
            sg.Button('Rename', key=self.keys['Rename'], size=size)
        ]
        return row

    def get_row_buttons_main_bottom(self):
        size = (8, 1)
        row = [
            sg.Button('Remove', key=self.keys['Remove'], size=size),
            sg.Button('Remove All', key=self.keys['RemoveAll'], size=size),
            sg.Button('Clone', key=self.keys['Clone'], size=size)
        ]
        return row
    
    # Data

    def _init(self):
        pass
    def _save(self, data):
        data[self.object_id] = self.item_dict.to_pairs()
    def _pull(self, values):
        pass
    def _load(self, data):
        self.item_dict.clear()
        pairs = data[self.object_id]
        for k, v in pairs:
            self.item_dict[k] = v
    def _push(self, window):
        highlighted = [self.selection] if self.selection else []
        sge_listbox = window[self.keys['Listbox']]
        sge_listbox.update(self.item_dict.keys())
        sge_listbox.set_value(highlighted)
        self.update_details(window)
    def _init_window(self, window):
        window[self.keys['Listbox']].Widget.config(activestyle='none')
        self.push(window)
    
    # Keys and Events
    
    def define_keys(self):
        super().define_keys()
        self.add_key('Listbox')
        self.add_key('Details')
        self.add_key('Add')
        self.add_key('Edit')
        self.add_key('Rename')
        self.add_key('Remove')
        self.add_key('RemoveAll')
        self.add_key('Clone')
        self.add_key('MoveUp')
        self.add_key('MoveDown')
        self.add_key('MoveToTop')
        self.add_key('MoveToBottom')
    
    def define_events(self):
        super().define_events()
        def event_listbox(window, event, values, data):
            selections = values[self.keys['Listbox']]
            if len(selections):
                self.selection = selections[0]
                self.update_details(window)
        self.em.event_function(self.keys['Listbox'], event_listbox)
        
        def event_add(window, event, values, data):
            item = Popups.edit_string('', label='Name:', title='Add')
            item = item.lstrip(self.lstrip).rstrip(self.rstrip)
            if not item:
                return
            if item in self.item_dict.key_list:
                Popups.ok('Entry of name "' + item + '" already exists.', title='Entry Exists')
                return
            self.item_dict[item] = None
            self.selection = item
            self.push(window)
            self.handle_event(window, self.keys['Edit'], values, data)
        self.em.event_function(self.keys['Add'], event_add)
        
        def event_edit(window, event, values, data):
            if not self.selection:
                return
            item = self.selection
            data = self.item_dict[item]
            data = self.edit_data(item, data)
            self.item_dict[item] = data
            self.push(window)
        self.em.event_function(self.keys['Edit'], event_edit)
        
        def event_rename(window, event, values, data):
            if not self.selection:
                return
            item = Popups.edit_string('', title='Rename', texts=['Previous: "' + self.selection + '"'])
            item = item.lstrip(self.lstrip).rstrip(self.rstrip)
            if not item:
                return
            item_data = self.item_dict[self.selection]
            if item in self.item_dict.key_list:
                if not Popups.confirm('Overwrite existing entry "' + item + '" ?'):
                    return
            index = self.item_dict.index(self.selection)
            self.item_dict.remove(self.selection)
            self.item_dict.insert(index, item, item_data)
            self.selection = item
            self.push(window)
        self.em.event_function(self.keys['Rename'], event_rename)
        
        def event_remove(window, event, values, data):
            if not self.selection:
                return
            self.item_dict.remove(self.selection)
            self.selection = None
            self.push(window)
        self.em.event_function(self.keys['Remove'], event_remove)
        
        def event_remove_all(window, event, values, data):
            if not len(self):
                return
            if not Popups.warning('Remove all entries?'):
                return
            self.item_dict.clear()
            self.selection = None
            self.push(window)
        self.em.event_function(self.keys['RemoveAll'], event_remove_all)
        
        def event_clone(window, event, values, data):
            if not self.selection:
                return
            i = 1
            item = self.selection
            while (item + str(i)) in self.item_dict.key_list:
                i += 1
            item = item + str(i)
            data = copy.deepcopy(self.item_dict[self.selection])
            self.item_dict.insert_after_key(self.selection, item, data)
            self.push(window)
        self.em.event_function(self.keys['Clone'], event_clone)
        
        def event_move_up(window, event, values, data):
            if not self.selection:
                return
            self.item_dict.move_forward(self.selection)
            self.push(window)
        self.em.event_function(self.keys['MoveUp'], event_move_up)
        
        def event_move_down(window, event, values, data):
            if not self.selection:
                return
            self.item_dict.move_back(self.selection)
            self.push(window)
        self.em.event_function(self.keys['MoveDown'], event_move_down)
        
        def event_move_to_top(window, event, values, data):
            if not self.selection:
                return
            self.item_dict.move_to_front(self.selection)
            self.push(window)
        self.em.event_function(self.keys['MoveToTop'], event_move_to_top)
        
        def event_move_to_bottom(window, event, values, data):
            if not self.selection:
                return
            self.item_dict.move_to_back(self.selection)
            self.push(window)
        self.em.event_function(self.keys['MoveToBottom'], event_move_to_bottom)

    # Other

    ### DetailList

    @abstractmethod
    def make_details(self, item, data) -> sg_utils.EmbedText:
        pass

    @abstractmethod
    def edit_data(self, item, data) -> str:
        pass

    @abstractmethod
    def data_to_string(self, data) -> str:
        pass

    @abstractmethod
    def data_from_string(self, data):
        pass

    # iLength

    def __len__(self):
        return len(self.item_dict)
    
    # Containable

    def popup_edit(self):
        layout = [self.get_layout()]
        layout.extend([
            [sg.HSeparator()],
            [sg.Ok()]
        ])
        em = self.prepare_event_manager()
        em.true_event('Ok')
        em.false_event(sg.WIN_CLOSED)
        return em.event_loop(sg.Window('Edit', layout, finalize=True))
    
    # Other
    
    def update_details(self, window):
        if not self.selection:
            window[self.keys['Details']]('')
            return
        item = self.selection
        data = self.item_dict[item]
        embed_text = self.make_details(item, data)
        sge_ml = window[self.keys['Details']]
        embed_text.print_to_multiline(sge_ml)

    def get_selection(self):
        if not self.selection:
            return None, None
        return self.selection, self.item_dict[self.selection]
    
    def get_through_selection(self):
        items = []
        if not self.selection:
            return items
        index = self.item_dict.index(self.selection)
        for i in range(0, index+1):
            item, data = self.item_dict.get_at(i)
            items.append((item, data))
        return items
    
    def get_pairs(self):
        return self.item_dict.to_pairs()

    def remove_through_selection(self):
        if not self.selection:
            return
        index = self.item_dict.index(self.selection)
        for i in range(index+1):
            self.item_dict.pop(0)
        self.selection = None

    def remove_all(self):
        self.item_dict.clear()
        self.selection = None
