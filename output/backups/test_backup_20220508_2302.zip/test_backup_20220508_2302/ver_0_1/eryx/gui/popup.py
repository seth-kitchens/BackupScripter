import textwrap
import time
from math import ceil

import PySimpleGUI as sg
from eryx import g
from eryx.gui.event_manager import EventManager
from eryx.misc import debug_utils as ddd
from eryx.gui.sg import utils as sg_utils

button_size = sg_utils.button_size

class PopupElement:
    def __init__(self, class_name, key, *args, unpack_layout=False, **kwargs):
        self.class_name = class_name
        self.key = key
        self.unpack_layout = unpack_layout
        self.args = args
        self.kwargs = kwargs

class Popup:
    def __init__(self):
        self.title = None
        self.header = None
        self.header_color = None
        self.subheader = None
        self.ok = None
        self.cancel = None
        self.auto_ok = None
        self.body = []
        self.sges = {} # key->PopupElement: sg element
        self.ges = {} # key->PopupElement: GuiElement
        self.values = None
        self.init_focus = None
    def get_layout(self):
        layout = []
        if self.header:
            header_color = self.header_color if self.header_color else g.colors.header
            layout.append([sg.Text(self.header, text_color=header_color)])
        if self.subheader:
            layout.append([sg.Text(self.subheader)])
            layout.append([sg.HSeparator()])
        for text in self.body:
            layout.append([sg.Text(text)])
        row = []

        for pe in self.sges.values():
            if pe == None:
                if not row:
                    row = [sg.Text('')]
                layout.append(row)
                row = []
            else:
                sge = pe.class_name(*pe.args, key=pe.key, **pe.kwargs)
                if pe.unpack_layout:
                    row.append(*sge)
                else:
                    row.append(sge)
        if row:
            layout.append(row)
        row = []

        for pe in self.ges.values():
            if pe == None:
                if not row:
                    row = [sg.Text('')]
                layout.append(row)
                row = []
            else:
                ge = pe.class_name(*pe.args, key=pe.key, **pe.kwargs)
                if pe.unpack_layout:
                    row.append(*ge)
                else:
                    row.append(ge)
        if row:
            layout.append(row)
        row = []

        row_buttons = []
        if self.ok:
            if not self.auto_ok == None:
                ok_text = self.ok + ' [' + str(self.auto_ok) + ']'
            else:
                ok_text = self.ok
            row_buttons.append(sg.Button(ok_text, key='ok', size=button_size.at_least('M', ok_text)))
        if self.cancel:
            row_buttons.append(sg.Button(self.cancel, key='cancel', size=button_size.at_least('M', self.cancel)))
        if row_buttons:
            row_buttons.insert(0, sg.Push())
            layout.append([sg.HSeparator()])
            layout.append(row_buttons)
        return layout
    
    def update_auto_ok(self, window, secs_left):
        window['ok'].update(text=self.ok + ' [' + str(ceil(secs_left)) + ']')
    
    def make_key(self):
        return str(time.time() + str(len(self.sges) + len(self.ges)))
    def add_newline_sge(self):
        key = self.make_key()
        self.sges[key] = None
    def add_newline_ge(self):
        key = self.make_key()
        self.ges[key] = None

    def open(self):
        true_events = []
        false_events = [sg.WIN_CLOSED]

        if self.ok:
            true_events.append('ok')
        if self.cancel:
            false_events.append('cancel')

        layout = self.get_layout()
        title = self.title if self.title else ''
        window = sg.Window(title, layout, finalize=True)
        if self.init_focus:
            we = window[self.init_focus]
            we.set_focus()
            sg_utils.set_cursor_to_end(we)
        if self.auto_ok:
            em = EventManager(true_events=true_events, false_events=false_events)
            em.data('self', self)
            def uf(window, event, values, data):
                popup = data['self']
                secs_passed = data['secs_passed']
                secs_left = popup.auto_ok - secs_passed
                popup.update_auto_ok(window, secs_left)
                if secs_left < -0.2:
                    return False
                return None
            em.update_function(uf)
            rv = em.timed_event_loop(window)
        else:
            em = EventManager(true_events=true_events, false_events=false_events)
            rv = em.event_loop(window)
        self.values = em.values
        return rv

class PopupBuilder:
    def __init__(self) -> None:
        """Some elements are ordered (body text, ges/sges, etc)
        and some aren't (ok button, title, etc) The ordered elements
        form the body of the popup, between any headers or buttons"""
        self.popup = Popup()

    # Ordered

    def text(self, s):
        """Ordered"""
        self.popup.body.append(s)
        return self
    def textwrap(self, s, width=70):
        """Ordered"""
        strings = s.split('\n')
        wrapped_strings = []
        for string in strings:
            wrapped_strings.append(textwrap.fill(string, width))
        s = '\n'.join(wrapped_strings)
        self.popup.body.append(s)
        return self
    def texts(self, l):
        """Ordered. Ignores empty list"""
        for text in l:
            self.popup.body.append(text)
        return self
    def sge(self, pe=None):
        """Ordered"""
        if not pe:
            self.popup.add_newline_sge()
        else:
            self.popup.sges[pe.key] = pe
        return self
    def ge(self, pe=None):
        """Ordered"""
        if not pe:
            self.popup.add_newline_ge()
        else:
            self.popup.ges[pe.key] = pe
        return self
    
    # Unordered

    def title(self, s):
        """Unordered"""
        self.popup.title = s
        return self
    def header(self, s, color=None):
        """Unordered"""
        self.popup.header = s
        if color:
            self.popup.header_color = color
        return self
    def subheader(self, s):
        """Unordered"""
        self.popup.subheader = s
        return self
    def ok(self, s='OK'):
        """Unordered"""
        self.popup.ok = s
        return self
    def cancel(self, s='Cancel'):
        """Unordered"""
        self.popup.cancel = s
        return self
    def auto_ok(self, secs=3):
        """Unordered"""
        if not self.popup.ok:
            self.popup.ok = 'OK'
        self.popup.auto_ok = secs
        return self
    def init_focus(self, key):
        """Unordered"""
        self.popup.init_focus = key
        return self
    
    # Finalizers
    
    def get(self):
        """Finalizer. Returns Popup object."""
        return self.popup
    def open(self):
        """Finalizer. Opens popup window."""
        return self.popup.open()
    def open_get_values(self):
        """Finalizer. Opens popup window, then returns rv from event
        (non-None that closed window) and values from last sg.Window.read() call"""
        rv = self.popup.open()
        values = self.popup.values
        return rv, values
    def get_layout(self):
        return self.popup.get_layout()
    
    # Templates
    
    class T:
        def error():
            return PopupBuilder().title('Error').header('Error', g.colors.error).ok()
        def warning():
            return PopupBuilder().title('Warning').header('Warning', g.colors.warning).ok().cancel()

class Popups:
    def ok(text, title='', texts=None):
        texts = texts if texts else []
        return PopupBuilder().ok().title(title).text(text).texts(texts).open()
    def confirm(text, title='Confirm', texts=None):
        texts = texts if texts else []
        return PopupBuilder().ok().cancel().title(title).text(text).texts(texts).open()
    def error(text, texts=None):
        texts = texts if texts else []
        return PopupBuilder.T.error().text(text).texts(texts).open()
    def warning(text, texts=None):
        texts = texts if texts else []
        return PopupBuilder.T.warning().text(text).texts(texts).open()
    def edit_string(s, label=None, title='', texts=None):
        texts = texts if texts else []
        pb = PopupBuilder().ok().cancel().title(title).texts(texts)
        if label != None:
            pb.sge(PopupElement(sg.Text, 'Label', label))
        pb.sge(
            PopupElement(sg.Input, 'In', s)
        ).init_focus('In')
        rv, values = pb.open_get_values()
        return values['In'] if rv else s
