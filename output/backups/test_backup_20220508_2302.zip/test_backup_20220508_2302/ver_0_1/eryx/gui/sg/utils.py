from typing import Any
import PySimpleGUI as sg
import tkinter as tk

class button_size:
    XXXS = 2
    XXS = 4
    XS = 6
    S = 8
    M = 10
    L = 12
    XL = 14
    XXL = 16
    XXXL = 18
    def at_least(size, text):
        """Autosize for button with min width. Useful for uniform-width buttons with varying text.
        Returns width:int
        Size can be: str | int.\n
        If str, w=button_size.size\n
        If int, w=(size, 1)"""
        if isinstance(size, str):
            w = button_size.__dict__[size]
        elif isinstance(size, int):
            w = size
        if len(text) > w:
            w = len(text) + 1
        return w

def browse_folder_button(text, key): return sg.Input(key=key, enable_events=True, visible=False), sg.FolderBrowse(text)
def browse_files_button(text, key): return sg.Input(key=key, enable_events=True, visible=False), sg.FilesBrowse(text)

def browse_folder(window:sg.Window, initialdir=None):
    if sg.running_mac():  # macs don't like seeing the parent window (go firgure)
        folder_name = tk.filedialog.askdirectory(initialdir=initialdir)  # show the 'get folder' dialog box
    else:
        folder_name = tk.filedialog.askdirectory(initialdir=initialdir, parent=window.TKroot)  # show the 'get folder' dialog box
    return folder_name

def browse_file(window:sg.Window, initialdir=None):
    if sg.running_mac():  # macs don't like seeing the parent window (go firgure)
        folder_name = tk.filedialog.askopenfilename(initialdir=initialdir)  # show the 'get folder' dialog box
    else:
        folder_name = tk.filedialog.askopenfilename(initialdir=initialdir, parent=window.TKroot)  # show the 'get folder' dialog box
    return folder_name

def set_cursor_to_end(sg_element):
    if isinstance(sg_element, sg.Input):
        sg_element.Widget.icursor(len(sg_element.get()))

def multiline_append_str(sge_ml, s):
    sge_ml.update(s, append=True)
def multiline_append_color_text(sge_ml, s, text_color=None, background_color=None):
    kwargs = {}
    if text_color != None:
        kwargs['text_color_for_value'] = text_color
        kwargs['background_color_for_value'] = background_color
    sge_ml.update(s, append=True, **kwargs)

class Menu:
    sep = '::'
    def __init__(self, display_text, menu_key=None):
        self.display_text = display_text
        self.menu_key = menu_key
        if menu_key:
            self.event_key = display_text + self.sep + menu_key
            self.id = menu_key
        else:
            self.event_key = display_text
            self.id = display_text
        self.choices = {}
    def __getitem__(self, id):
        if not id in self.choices:
            self.choices[id] = Menu(display_text=id)
        return self.choices[id]
    def __setitem__(self, id, display_text):
        if not id in self.choices:
            self.choices[id] = Menu(display_text=display_text, menu_key=id)
    def get_def(self):
        choices = []
        for choice in self.choices.values():
            choices.append(choice.get_def())
        
        if choices:
            menu_def = [self.event_key, choices]
        else:
            menu_def = self.event_key
        
        return menu_def
    def event(self, id):
        if self.id == id:
            return self.event_key
        for choice in self.choices.values():
            if (rv := choice.event(id)) != None:
                return rv
        return None

class MenuBar:
    def __init__(self):
        self.columns = {}
    def __getitem__(self, id):
        if not id in self.columns:
            self.columns[id] = Menu(display_text=id)
        return self.columns[id]
    def get_def(self):
        menu_def = []
        for column in self.columns.values():
            menu_def.append(column.get_def())
        return menu_def
    def event(self, id):
        for column in self.columns.values():
            if (rv := column.event(id)) != None:
                return rv
        return None

class EmbedText:
    def __init__(self, s=None) -> None:
        self.strings:list[tuple[dict[str, str], str]] = []
        if s:
            self += s
    def __iadd__(self, other):
        return self.append(other)
    def append(self, other):
        if isinstance(other, str):
            self.strings.append([{}, other])
        else:
            s_formats = other[0]
            formats = EmbedText.process_format_string(s_formats)
            s = other[1]
            self.strings.append([formats, s])
        return self
    def process_format_string(formats):
        format_list = formats.split(';')
        f = {}
        for s_f in format_list:
            parts = s_f.split(':')
            k = parts[0]
            if len(parts) > 1:
                v = parts[1]
            else:
                v = None
            f[k] = v
        return f
    def color(self, s, text_color=None, background_color=None):
        f = {}
        if text_color:
            f['text_color'] = text_color
        if background_color:
            f['background_color'] = background_color
        self.strings.append((f, s))
    def print_to_multiline(self, sge_ml:sg.Multiline):
        sge_ml.update('')
        for f, s in self.strings:
            text_color = background_color = None
            if 'text_color' in f.keys():
                text_color = f['text_color']
            if 'background_color' in f.keys():
                background_color = f['background_color']
            multiline_append_color_text(sge_ml, s, text_color, background_color)


def test():
    et = EmbedText()
    et += 'This is unformatted text, but '
    et += ('')
