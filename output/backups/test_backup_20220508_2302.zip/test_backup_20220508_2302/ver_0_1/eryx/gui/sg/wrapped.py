import PySimpleGUI as sg

# Wrapped elements

def FrameColumn(title, *args, frame_kwargs=None, column_kwargs=None, layout=None, **kwargs):
    """A frame with its layout wrapped in a column. *args and **kwargs are passed to both"""
    if layout == None:
        raise ValueError("Layout must be given")
    if frame_kwargs == None:
        frame_kwargs = {}
    if column_kwargs == None:
        column_kwargs = {}
    column = sg.Column(layout=layout, *args, **kwargs, **column_kwargs)
    return sg.Frame(title=title, *args, **kwargs, **frame_kwargs, layout=[[column]])
