from pydoc import resolve
import time
from typing import Callable, Hashable
import inspect

import PySimpleGUI as sg

from eryx.misc import debug_utils as ddd

class EventManager:
    def __init__(self, event_data=None, true_events=None, false_events=None, events:list[tuple[str, Callable]]=None):
        self.handle_event_funcs = []
        self._bool_events = {}
        self.event_funcs = {}
        self.update_functions = []
        self.init_functions = []
        self.save_functions = []
        self.load_functions = []
        self.pull_functions = []
        self.push_functions = []
        self.event_data = event_data if event_data else {}
        self.keys = {}
        self.values = None
        if true_events:
            for e in true_events:
                self.true_event(e)
        if false_events:
            for e in false_events:
                self.false_event(e)
        if events:
            for e, func in events:
                self.event_function(e, func)
    def handle_event_function(self, func):
        self.handle_event_funcs.append(func)
        return self
    def event_function_wrapped(self, event, func, passed_args='wevd'):
        def ef(window, event, values, data):
            kwargs = {}
            if 'w' in passed_args: kwargs['window'] = window
            if 'e' in passed_args: kwargs['event'] = event
            if 'v' in passed_args: kwargs['values'] = values
            if 'd' in passed_args: kwargs['data'] = data
            return func(**kwargs)
        self.event_funcs[event] = ef
    def event_function(self, event, func):
        self.event_funcs[event] = func
    def event_functions(self, events, func):
        for event in events:
            self.event_funcs[event] = func
    def update_function(self, func):
        self.update_functions.append(func)
        return self
    def save_function(self, func, data):
        def f():
            func(data)
        self.save_functions.append(f)
        return self
    def load_function(self, func, data):
        def f():
            func(data)
        self.load_functions.append(f)
        return self
    def pull_function(self, func):
        self.pull_functions.append(func)
        return self
    def push_function(self, func):
        self.push_functions.append(func)
        return self
    def init_window_function(self, func):
        self.init_functions.append(func)
        return self
    def true_event(self, event):
        self._bool_events[event] = True
        return self
    def false_event(self, event):
        self._bool_events[event] = False
        return self
    def bool_events(self, true_events=None, false_events=None):
        if true_events:
            for event in true_events:
                self._bool_events[event] = True
        if false_events:
            for event in false_events:
                self._bool_events[event] = False
        return self
    def data(self, k, v):
        self.event_data[k] = v
        return self
    def handle_event(self, window, event, values, data=None):
        data = data if data != None else self.event_data
        if event in self._bool_events.keys():
            return self._bool_events[event]
        for func in self.handle_event_funcs:
            func(window, event, values, data)
        if not event in self.event_funcs.keys():
            return None
        return self.event_funcs[event](window, event, values, data)
    def event_loop(self, window):
        for func in self.load_functions:
            func()
        for func in self.init_functions:
            func(window)
        for func in self.push_functions:
            func(window)
        rv = None
        while True:
            event, values = window.read()
            ddd.handle_event(event, values)
            for uf in self.update_functions:
                if (rv := uf(window, event, values, self.event_data)) != None:
                    break
            if (rv := self.handle_event(window, event, values)) != None:
                break
        window.close()
        if rv:
            for pull_function in self.pull_functions:
                pull_function(values)
            for save_function in self.save_functions:
                save_function()
        self.values = values
        return rv
    def timed_event_loop(self, window):
        start_time = time.time()
        rv = None
        while True:
            event, values = window.read(50)
            self.data('secs_passed', time.time() - start_time)
            for uf in self.update_functions:
                if (rv := uf(window, event, values, self.event_data)) != None:
                    break
            if rv != None:
                break
            if (rv := self.handle_event(window, event, values)) != None:
                break
        window.close()
        if rv:
            for pull_function in self.pull_functions:
                pull_function(values)
            for save_function in self.save_functions:
                save_function()
        self.values = values
        return rv
